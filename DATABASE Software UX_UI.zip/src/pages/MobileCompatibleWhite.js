import "./MobileCompatibleWhite.css";

const MobileCompatibleWhite = () => {
  return (
    <div className="mobile-compatible-white">
      <header className="sub-frame-a">
        <img
          className="friday-intel-wordmark-black1"
          loading="lazy"
          alt=""
          src="/friday-intel-wordmark-black.svg"
        />
        <img
          className="darllight-mode-icon2"
          loading="lazy"
          alt=""
          src="/darllight-mode2@2x.png"
        />
      </header>
      <section className="parent-container">
        <div className="intel-monogram">
          <img
            className="fridayintel-monogram-black-1-icon"
            loading="lazy"
            alt=""
            src="/fridayintel-monogram-black-1.svg"
          />
          <h1 className="this-window-is-container">
            <p className="this-window-is">{`This window is not compatible with `}</p>
            <p className="mobile-devices">mobile devices</p>
          </h1>
        </div>
      </section>
      <div className="frame-c">
        <div className="friday-intel-pvt5">
          © 2022-23 Friday Intel Pvt. Ltd.
        </div>
      </div>
    </div>
  );
};

export default MobileCompatibleWhite;
