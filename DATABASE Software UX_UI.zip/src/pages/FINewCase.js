import { TextField, InputAdornment, Icon, IconButton } from "@mui/material";
import FrameComponent1 from "../components/FrameComponent1";
import FrameComponent from "../components/FrameComponent";
import BottomBar from "../components/BottomBar";
import "./FINewCase.css";

const FINewCase = () => {
  return (
    <div className="fi-new-case">
      <FrameComponent1 notifyIcon="/notifyicon@2x.png" />
      <section className="frame-section">
        <FrameComponent />
        <BottomBar />
      </section>
      <section className="footer">
        <div className="bottom-bar">
          <img className="bottom-bar-icon" alt="" src="/bottom-bar.svg" />
          <img
            className="friday-intel-wordmark-white"
            loading="lazy"
            alt=""
            src="/friday-intel-wordmark-white.svg"
          />
          <div className="bottom-icons">
            <div className="footer-icons">
              <div className="footer-icons-frame">
                <div className="tp-onclick">
                  <div className="onclick" />
                  <img
                    className="finnthehuman-icon"
                    alt=""
                    src="/finnthehuman-1.svg"
                  />
                </div>
                <div className="bottom-icons1">
                  <div className="icons">
                    <div className="bottom-icons2">
                      <img
                        className="bug-icon"
                        loading="lazy"
                        alt=""
                        src="/bug@2x.png"
                      />
                      <img
                        className="database-icon"
                        loading="lazy"
                        alt=""
                        src="/database.svg"
                      />
                      <img
                        className="shieldcheck-icon"
                        loading="lazy"
                        alt=""
                        src="/shieldcheck.svg"
                      />
                      <img
                        className="alien-icon"
                        loading="lazy"
                        alt=""
                        src="/alien@2x.png"
                      />
                      <img
                        className="shieldcheck-icon1"
                        alt=""
                        src="/shieldcheck.svg"
                      />
                      <img className="alien-icon1" alt="" src="/alien@2x.png" />
                      <img className="bug-icon1" alt="" src="/bug@2x.png" />
                      <img className="alien-icon2" alt="" src="/alien@2x.png" />
                      <img className="bug-icon2" alt="" src="/bug@2x.png" />
                      <input className="alien" type="checkbox" />
                      <input className="bug" type="checkbox" />
                      <input className="alien1" type="checkbox" />
                      <img className="bug-icon3" alt="" src="/bug@2x.png" />
                      <img
                        className="shieldcheck-icon2"
                        alt=""
                        src="/shieldcheck.svg"
                      />
                      <img
                        className="shieldcheck-icon3"
                        alt=""
                        src="/shieldcheck.svg"
                      />
                    </div>
                  </div>
                </div>
              </div>
              <img
                className="caretcircleadd-icon"
                alt=""
                src="/caretcircleadd.svg"
              />
            </div>
          </div>
        </div>
        <div className="alien-icon3">
          <TextField
            className="bottom-iconscanvas-search"
            placeholder="Search...."
            variant="outlined"
            InputProps={{
              startAdornment: (
                <img width="24px" height="24px" src="/search-1.svg" />
              ),
            }}
            sx={{
              "& fieldset": { borderColor: "rgba(0, 0, 0, 0.2)" },
              "& .MuiInputBase-root": {
                height: "40px",
                backgroundColor: "rgba(255, 255, 255, 0.2)",
                paddingLeft: "10px",
                borderRadius: "30px",
              },
              "& .MuiInputBase-input": {
                paddingLeft: "14px",
                color: "rgba(0, 0, 0, 0.2)",
              },
            }}
          />
        </div>
      </section>
    </div>
  );
};

export default FINewCase;
