import { useCallback } from "react";
import { TextField, InputAdornment, Icon, IconButton } from "@mui/material";
import Input from "../components/Input";
import { useNavigate } from "react-router-dom";
import "./LogIn.css";

const LogIn = () => {
  const navigate = useNavigate();

  const onForgotPasswordTextClick = useCallback(() => {
    navigate("/forgot-password");
  }, [navigate]);

  return (
    <div className="log-in">
      <section className="log-in-frame">
        <div className="f-r-a-m-e-parent">
          <div className="f-r-a-m-e">
            <img className="navbar-icon" alt="" src="/navbar.svg" />
            <img
              className="darllight-mode-icon1"
              loading="lazy"
              alt=""
              src="/darllight-mode1@2x.png"
            />
          </div>
          <div className="frame-wrapper">
            <div className="welcome-back-parent">
              <h1 className="welcome-back">Welcome back</h1>
              <div className="text-login-credentials">
                <div className="please-enter-your">
                  Please enter your login credentials.
                </div>
              </div>
              <div className="input-company-domain">
                <Input
                  propAlignSelf="unset"
                  propWidth="380px"
                  propWidth1="142px"
                />
                <div className="checkbox">
                  <div className="password">Password</div>
                  <TextField
                    className="forgot-password-text"
                    placeholder="*********"
                    variant="outlined"
                    InputProps={{
                      endAdornment: (
                        <img
                          width="24px"
                          height="24px"
                          src="/-icon-x-close-delete.svg"
                        />
                      ),
                    }}
                    sx={{
                      "& fieldset": { border: "none" },
                      "& .MuiInputBase-root": {
                        height: "48px",
                        paddingRight: "12px",
                        borderRadius: "0px 0px 0px 0px",
                        fontSize: "12px",
                      },
                      "& .MuiInputBase-input": {
                        color: "rgba(43, 43, 43, 0.5)",
                      },
                    }}
                  />
                </div>
              </div>
              <div className="information-frame">
                <div className="content">
                  <div className="links-instance">
                    <input className="checkbox1" type="checkbox" />
                    <div className="remember-me">Remember me</div>
                  </div>
                  <div
                    className="forgot-password2"
                    onClick={onForgotPasswordTextClick}
                  >
                    Forgot password
                  </div>
                </div>
              </div>
              <div className="buttons-primary-parent">
                <TextField
                  className="buttons-primary"
                  placeholder="Login"
                  variant="outlined"
                  InputProps={{
                    endAdornment: (
                      <img width="18px" height="18px" src="/arrowright.svg" />
                    ),
                  }}
                  sx={{
                    "& fieldset": { border: "none" },
                    "& .MuiInputBase-root": {
                      height: "45px",
                      backgroundColor: "rgba(28, 28, 28, 0.7)",
                      paddingRight: "168px",
                      borderRadius: "14px",
                      fontSize: "14px",
                    },
                    "& .MuiInputBase-input": { color: "#fff" },
                  }}
                />
                <div className="links1">
                  <div className="dont-have-an1">Don’t have an account ?</div>
                  <div className="contact-us1">Contact Us</div>
                </div>
              </div>
            </div>
          </div>
          <div className="friday-intel-llp">© 2023-24 Friday Intel LLP</div>
        </div>
        <div className="placeholder-image-wrapper">
          <img
            className="placeholder-image2"
            loading="lazy"
            alt=""
            src="/placeholder--image1@2x.png"
          />
        </div>
      </section>
      <div className="links2">
        <div className="dont-have-an2">
          Don’t have an account ! Sorry you’re not welcome then :(
        </div>
        <div className="contact-us2">Contact Us</div>
      </div>
      <div className="copyright-text">
        <div className="friday-intel-pvt2">© 2022 Friday Intel Pvt. Ltd.</div>
      </div>
    </div>
  );
};

export default LogIn;
