import NewCaseHalf from "../components/NewCaseHalf";
import "./LoadCase.css";

const LoadCase = () => {
  return (
    <div className="load-case3">
      <section className="frame-container1">
        <header className="header-1">
          <div className="rectangle">
            <div className="bookmark-icon">
              <div className="circle" />
              <div className="shadow" />
              <div className="button">
                <img className="star-icon" alt="" src="/star@2x.png" />
              </div>
            </div>
            <div className="icon-breadcrumb">
              <div className="breadcrumb">
                <div className="navigation1">Dashboard</div>
              </div>
              <div className="icon-button-container">/</div>
              <div className="button1">
                <h3 className="chevron-right-filled">Case 1</h3>
              </div>
            </div>
          </div>
          <div className="content2">
            <div className="search-l">
              <div className="table-elements-table-cell">
                <div className="rectangle1">
                  <img
                    className="friday-intel-monogram-black"
                    loading="lazy"
                    alt=""
                    src="/friday-intel-monogram-black.svg"
                  />
                </div>
                <img
                  className="table-elements-table-cell-child"
                  alt=""
                  src="/line-249.svg"
                />
                <div className="typography64">Type Something|</div>
              </div>
              <img
                className="search-icon"
                loading="lazy"
                alt=""
                src="/search.svg"
              />
            </div>
            <div className="header-options">
              <img
                className="timelapse-icon"
                loading="lazy"
                alt=""
                src="/timelapseicon.svg"
              />
              <img
                className="sun-icon"
                loading="lazy"
                alt=""
                src="/sunicon@2x.png"
              />
              <img
                className="notify-icon"
                loading="lazy"
                alt=""
                src="/notifyicon1@2x.png"
              />
              <img
                className="user-icon"
                loading="lazy"
                alt=""
                src="/usericon@2x.png"
              />
            </div>
          </div>
        </header>
      </section>
      <section className="rectangle2">
        <div className="divider-horizontal">
          <NewCaseHalf
            new1="New"
            propMarginLeft="unset"
            propWidth="unset"
            propAlignSelf="stretch"
            propTop="unset"
            propBottom="35.5px"
          />
          <div className="load-case4">
            <div className="load-case-child" />
            <div className="arrowcircleright1" />
            <img
              className="loopergroup-icon"
              alt=""
              src="/loopergroup@2x.png"
            />
            <div className="chevron-left-filled">
              <h1 className="load-case5">
                <span className="load-case-txt-container3">
                  <p className="load3">Load</p>
                  <p className="case3">Case</p>
                </span>
              </h1>
              <img className="icon-button" alt="" src="/vector-1.svg" />
            </div>
          </div>
          <NewCaseHalf
            new1="Read "
            propMarginLeft="unset"
            propWidth="unset"
            propAlignSelf="stretch"
            propTop="unset"
            propBottom="35.5px"
          />
        </div>
        <div className="mui-table1">
          <div className="tableelementstableheadrow1">
            <div className="tableelementstablehead-parent">
              <div className="tableelementstablehead4">
                <input className="masked1" type="checkbox" />
                <img
                  className="arrowsdownup-icon4"
                  loading="lazy"
                  alt=""
                  src="/arrowsdownup.svg"
                />
                <div className="content3">
                  <div className="mask8">
                    <img
                      className="arrowdownwardfilled-icon8"
                      alt=""
                      src="/arrowdownwardfilled.svg"
                    />
                  </div>
                  <div className="head4">Title</div>
                  <div className="mask9">
                    <img
                      className="arrowdownwardfilled-icon9"
                      alt=""
                      src="/arrowdownwardfilled.svg"
                    />
                  </div>
                </div>
              </div>
              <div className="tableelementstablehead5">
                <div className="mask10">
                  <img
                    className="arrowdownwardfilled-icon10"
                    alt=""
                    src="/arrowdownwardfilled.svg"
                  />
                </div>
                <img
                  className="arrowsdownup-icon5"
                  alt=""
                  src="/arrowsdownup.svg"
                />
                <div className="head5">Node Count</div>
                <div className="mask11">
                  <img
                    className="arrowdownwardfilled-icon11"
                    alt=""
                    src="/arrowdownwardfilled.svg"
                  />
                </div>
              </div>
              <div className="tableelementstablehead6">
                <div className="mask12">
                  <img
                    className="arrowdownwardfilled-icon12"
                    alt=""
                    src="/arrowdownwardfilled.svg"
                  />
                </div>
                <img
                  className="arrowsdownup-icon6"
                  alt=""
                  src="/arrowsdownup.svg"
                />
                <div className="head6">
                  <span>{`Creation Time `}</span>
                  <span className="utc-5302">(UTC +5:30)</span>
                </div>
                <div className="mask13">
                  <img
                    className="arrowdownwardfilled-icon13"
                    alt=""
                    src="/arrowdownwardfilled.svg"
                  />
                </div>
              </div>
              <div className="tableelementstablehead7">
                <div className="mask14">
                  <img
                    className="arrowdownwardfilled-icon14"
                    alt=""
                    src="/arrowdownwardfilled.svg"
                  />
                </div>
                <img
                  className="arrowsdownup-icon7"
                  alt=""
                  src="/arrowsdownup.svg"
                />
                <div className="head7">
                  <span>{`Last Update `}</span>
                  <span className="utc-5303">(UTC +5:30)</span>
                </div>
                <div className="mask15">
                  <img
                    className="arrowdownwardfilled-icon15"
                    alt=""
                    src="/arrowdownwardfilled.svg"
                  />
                </div>
              </div>
            </div>
            <div className="dividerhorizontal17" />
          </div>
          <div className="tableelementstablecellrow16">
            <div className="of">
              <div className="tableelementstablecell64">
                <div className="checkbox18">
                  <input className="padding16" type="checkbox" />
                  <div className="label16">Label</div>
                  <div className="loader81">
                    <div className="row-container" />
                    <div className="frame-with-masked-checkbox" />
                  </div>
                </div>
                <div className="typography65">
                  <div className="cell65">Paki</div>
                  <div className="loader82">
                    <div className="content-cell" />
                    <div className="table-elements-table-row" />
                  </div>
                </div>
              </div>
              <div className="tableelementstablecell65">
                <div className="typography66">
                  <div className="cell66">1</div>
                </div>
                <div className="loader83">
                  <div className="masked2" />
                  <div className="arrows-down-up-head" />
                </div>
              </div>
              <div className="tableelementstablecell66">
                <div className="typography67">
                  <div className="cell67">2022-1-12 12:12:32</div>
                </div>
                <div className="loader84">
                  <div className="icon-button-container-chevron" />
                  <div className="arrows-down-up-tail" />
                </div>
              </div>
              <div className="tableelementstablecell67">
                <div className="typography68">
                  <div className="cell68">2022-1-12 12:12:32</div>
                </div>
                <div className="loader85">
                  <div className="loader-child150" />
                  <div className="divider-horizontal1" />
                </div>
              </div>
            </div>
            <div className="dividerhorizontal18" />
          </div>
          <div className="tableelementstablecellrow17">
            <div className="tableelementstablecell-parent1">
              <div className="tableelementstablecell68">
                <div className="checkbox19">
                  <input className="padding17" type="checkbox" />
                  <div className="label17">Label</div>
                  <div className="loader86">
                    <div className="loader-child151" />
                    <div className="loader-child152" />
                  </div>
                </div>
                <div className="typography69">
                  <div className="cell69">Paki</div>
                  <div className="loader87">
                    <div className="loader-child153" />
                    <div className="loader-child154" />
                  </div>
                </div>
              </div>
              <div className="tableelementstablecell69">
                <div className="typography70">
                  <div className="cell70">1</div>
                </div>
                <div className="loader88">
                  <div className="loader-child155" />
                  <div className="loader-child156" />
                </div>
              </div>
              <div className="tableelementstablecell70">
                <div className="typography71">
                  <div className="cell71">2022-1-12 12:12:32</div>
                </div>
                <div className="loader89">
                  <div className="loader-child157" />
                  <div className="loader-child158" />
                </div>
              </div>
              <div className="tableelementstablecell71">
                <div className="typography72">
                  <div className="cell72">2022-1-12 12:12:32</div>
                </div>
                <div className="loader90">
                  <div className="loader-child159" />
                  <div className="loader-child160" />
                </div>
              </div>
            </div>
            <div className="dividerhorizontal19" />
          </div>
          <div className="tableelementstablecellrow18">
            <div className="tableelementstablecell-parent2">
              <div className="tableelementstablecell72">
                <div className="checkbox20">
                  <input className="padding18" type="checkbox" />
                  <div className="label18">Label</div>
                  <div className="loader91">
                    <div className="loader-child161" />
                    <div className="loader-child162" />
                  </div>
                </div>
                <div className="typography73">
                  <div className="cell73">Paki</div>
                  <div className="loader92">
                    <div className="loader-child163" />
                    <div className="loader-child164" />
                  </div>
                </div>
              </div>
              <div className="tableelementstablecell73">
                <div className="typography74">
                  <div className="cell74">1</div>
                </div>
                <div className="loader93">
                  <div className="loader-child165" />
                  <div className="loader-child166" />
                </div>
              </div>
              <div className="tableelementstablecell74">
                <div className="typography75">
                  <div className="cell75">2022-1-12 12:12:32</div>
                </div>
                <div className="loader94">
                  <div className="loader-child167" />
                  <div className="loader-child168" />
                </div>
              </div>
              <div className="tableelementstablecell75">
                <div className="typography76">
                  <div className="cell76">2022-1-12 12:12:32</div>
                </div>
                <div className="loader95">
                  <div className="loader-child169" />
                  <div className="loader-child170" />
                </div>
              </div>
            </div>
            <div className="dividerhorizontal20" />
          </div>
          <div className="tableelementstablecellrow19">
            <div className="tableelementstablecell-parent3">
              <div className="tableelementstablecell76">
                <div className="checkbox21">
                  <input className="padding19" type="checkbox" />
                  <div className="label19">Label</div>
                  <div className="loader96">
                    <div className="loader-child171" />
                    <div className="loader-child172" />
                  </div>
                </div>
                <div className="typography77">
                  <div className="cell77">Paki</div>
                  <div className="loader97">
                    <div className="loader-child173" />
                    <div className="loader-child174" />
                  </div>
                </div>
              </div>
              <div className="tableelementstablecell77">
                <div className="typography78">
                  <div className="cell78">1</div>
                </div>
                <div className="loader98">
                  <div className="loader-child175" />
                  <div className="loader-child176" />
                </div>
              </div>
              <div className="tableelementstablecell78">
                <div className="typography79">
                  <div className="cell79">2022-1-12 12:12:32</div>
                </div>
                <div className="loader99">
                  <div className="loader-child177" />
                  <div className="loader-child178" />
                </div>
              </div>
              <div className="tableelementstablecell79">
                <div className="typography80">
                  <div className="cell80">2022-1-12 12:12:32</div>
                </div>
                <div className="loader100">
                  <div className="loader-child179" />
                  <div className="loader-child180" />
                </div>
              </div>
            </div>
            <div className="dividerhorizontal21" />
          </div>
          <div className="tableelementstablecellrow20">
            <div className="tableelementstablecell-parent4">
              <div className="tableelementstablecell80">
                <div className="checkbox22">
                  <input className="padding20" type="checkbox" />
                  <div className="label20">Label</div>
                  <div className="loader101">
                    <div className="loader-child181" />
                    <div className="loader-child182" />
                  </div>
                </div>
                <div className="typography81">
                  <div className="cell81">Paki</div>
                  <div className="loader102">
                    <div className="loader-child183" />
                    <div className="loader-child184" />
                  </div>
                </div>
              </div>
              <div className="tableelementstablecell81">
                <div className="typography82">
                  <div className="cell82">1</div>
                </div>
                <div className="loader103">
                  <div className="loader-child185" />
                  <div className="loader-child186" />
                </div>
              </div>
              <div className="tableelementstablecell82">
                <div className="typography83">
                  <div className="cell83">2022-1-12 12:12:32</div>
                </div>
                <div className="loader104">
                  <div className="loader-child187" />
                  <div className="loader-child188" />
                </div>
              </div>
              <div className="tableelementstablecell83">
                <div className="typography84">
                  <div className="cell84">2022-1-12 12:12:32</div>
                </div>
                <div className="loader105">
                  <div className="loader-child189" />
                  <div className="loader-child190" />
                </div>
              </div>
            </div>
            <div className="dividerhorizontal22" />
          </div>
          <div className="tableelementstablecellrow21">
            <div className="tableelementstablecell-parent5">
              <div className="tableelementstablecell84">
                <div className="checkbox23">
                  <input className="padding21" type="checkbox" />
                  <div className="label21">Label</div>
                  <div className="loader106">
                    <div className="loader-child191" />
                    <div className="loader-child192" />
                  </div>
                </div>
                <div className="typography85">
                  <div className="cell85">Paki</div>
                  <div className="loader107">
                    <div className="loader-child193" />
                    <div className="loader-child194" />
                  </div>
                </div>
              </div>
              <div className="tableelementstablecell85">
                <div className="typography86">
                  <div className="cell86">1</div>
                </div>
                <div className="loader108">
                  <div className="loader-child195" />
                  <div className="loader-child196" />
                </div>
              </div>
              <div className="tableelementstablecell86">
                <div className="typography87">
                  <div className="cell87">2022-1-12 12:12:32</div>
                </div>
                <div className="loader109">
                  <div className="loader-child197" />
                  <div className="loader-child198" />
                </div>
              </div>
              <div className="tableelementstablecell87">
                <div className="typography88">
                  <div className="cell88">2022-1-12 12:12:32</div>
                </div>
                <div className="loader110">
                  <div className="loader-child199" />
                  <div className="loader-child200" />
                </div>
              </div>
            </div>
            <div className="dividerhorizontal23" />
          </div>
          <div className="tableelementstablecellrow22">
            <div className="tableelementstablecell-parent6">
              <div className="tableelementstablecell88">
                <div className="checkbox24">
                  <input className="padding22" type="checkbox" />
                  <div className="label22">Label</div>
                  <div className="loader111">
                    <div className="loader-child201" />
                    <div className="loader-child202" />
                  </div>
                </div>
                <div className="typography89">
                  <div className="cell89">Paki</div>
                  <div className="loader112">
                    <div className="loader-child203" />
                    <div className="loader-child204" />
                  </div>
                </div>
              </div>
              <div className="tableelementstablecell89">
                <div className="typography90">
                  <div className="cell90">1</div>
                </div>
                <div className="loader113">
                  <div className="loader-child205" />
                  <div className="loader-child206" />
                </div>
              </div>
              <div className="tableelementstablecell90">
                <div className="typography91">
                  <div className="cell91">2022-1-12 12:12:32</div>
                </div>
                <div className="loader114">
                  <div className="loader-child207" />
                  <div className="loader-child208" />
                </div>
              </div>
              <div className="tableelementstablecell91">
                <div className="typography92">
                  <div className="cell92">2022-1-12 12:12:32</div>
                </div>
                <div className="loader115">
                  <div className="loader-child209" />
                  <div className="loader-child210" />
                </div>
              </div>
            </div>
            <div className="dividerhorizontal24" />
          </div>
          <div className="tableelementstablecellrow23">
            <div className="tableelementstablecell-parent7">
              <div className="tableelementstablecell92">
                <div className="checkbox25">
                  <input className="padding23" type="checkbox" />
                  <div className="label23">Label</div>
                  <div className="loader116">
                    <div className="loader-child211" />
                    <div className="loader-child212" />
                  </div>
                </div>
                <div className="typography93">
                  <div className="cell93">Paki</div>
                  <div className="loader117">
                    <div className="loader-child213" />
                    <div className="loader-child214" />
                  </div>
                </div>
              </div>
              <div className="tableelementstablecell93">
                <div className="typography94">
                  <div className="cell94">1</div>
                </div>
                <div className="loader118">
                  <div className="loader-child215" />
                  <div className="loader-child216" />
                </div>
              </div>
              <div className="tableelementstablecell94">
                <div className="typography95">
                  <div className="cell95">2022-1-12 12:12:32</div>
                </div>
                <div className="loader119">
                  <div className="loader-child217" />
                  <div className="loader-child218" />
                </div>
              </div>
              <div className="tableelementstablecell95">
                <div className="typography96">
                  <div className="cell96">2022-1-12 12:12:32</div>
                </div>
                <div className="loader120">
                  <div className="loader-child219" />
                  <div className="loader-child220" />
                </div>
              </div>
            </div>
            <div className="dividerhorizontal25" />
          </div>
          <div className="tableelementstablecellrow24">
            <div className="tableelementstablecell-parent8">
              <div className="tableelementstablecell96">
                <div className="checkbox26">
                  <input className="padding24" type="checkbox" />
                  <div className="label24">Label</div>
                  <div className="loader121">
                    <div className="loader-child221" />
                    <div className="loader-child222" />
                  </div>
                </div>
                <div className="typography97">
                  <div className="cell97">Paki</div>
                  <div className="loader122">
                    <div className="loader-child223" />
                    <div className="loader-child224" />
                  </div>
                </div>
              </div>
              <div className="tableelementstablecell97">
                <div className="typography98">
                  <div className="cell98">1</div>
                </div>
                <div className="loader123">
                  <div className="loader-child225" />
                  <div className="loader-child226" />
                </div>
              </div>
              <div className="tableelementstablecell98">
                <div className="typography99">
                  <div className="cell99">2022-1-12 12:12:32</div>
                </div>
                <div className="loader124">
                  <div className="loader-child227" />
                  <div className="loader-child228" />
                </div>
              </div>
              <div className="tableelementstablecell99">
                <div className="typography100">
                  <div className="cell100">2022-1-12 12:12:32</div>
                </div>
                <div className="loader125">
                  <div className="loader-child229" />
                  <div className="loader-child230" />
                </div>
              </div>
            </div>
            <div className="dividerhorizontal26" />
          </div>
          <div className="tableelementstablecellrow25">
            <div className="tableelementstablecell-parent9">
              <div className="tableelementstablecell100">
                <div className="checkbox27">
                  <input className="padding25" type="checkbox" />
                  <div className="label25">Label</div>
                  <div className="loader126">
                    <div className="loader-child231" />
                    <div className="loader-child232" />
                  </div>
                </div>
                <div className="typography101">
                  <div className="cell101">Paki</div>
                  <div className="loader127">
                    <div className="loader-child233" />
                    <div className="loader-child234" />
                  </div>
                </div>
              </div>
              <div className="tableelementstablecell101">
                <div className="typography102">
                  <div className="cell102">1</div>
                </div>
                <div className="loader128">
                  <div className="loader-child235" />
                  <div className="loader-child236" />
                </div>
              </div>
              <div className="tableelementstablecell102">
                <div className="typography103">
                  <div className="cell103">2022-1-12 12:12:32</div>
                </div>
                <div className="loader129">
                  <div className="loader-child237" />
                  <div className="loader-child238" />
                </div>
              </div>
              <div className="tableelementstablecell103">
                <div className="typography104">
                  <div className="cell104">2022-1-12 12:12:32</div>
                </div>
                <div className="loader130">
                  <div className="loader-child239" />
                  <div className="loader-child240" />
                </div>
              </div>
            </div>
            <div className="dividerhorizontal27" />
          </div>
          <div className="tableelementstablecellrow26">
            <div className="tableelementstablecell-parent10">
              <div className="tableelementstablecell104">
                <div className="checkbox28">
                  <input className="padding26" type="checkbox" />
                  <div className="label26">Label</div>
                  <div className="loader131">
                    <div className="loader-child241" />
                    <div className="loader-child242" />
                  </div>
                </div>
                <div className="typography105">
                  <div className="cell105">Paki</div>
                  <div className="loader132">
                    <div className="loader-child243" />
                    <div className="loader-child244" />
                  </div>
                </div>
              </div>
              <div className="tableelementstablecell105">
                <div className="typography106">
                  <div className="cell106">1</div>
                </div>
                <div className="loader133">
                  <div className="loader-child245" />
                  <div className="loader-child246" />
                </div>
              </div>
              <div className="tableelementstablecell106">
                <div className="typography107">
                  <div className="cell107">2022-1-12 12:12:32</div>
                </div>
                <div className="loader134">
                  <div className="loader-child247" />
                  <div className="loader-child248" />
                </div>
              </div>
              <div className="tableelementstablecell107">
                <div className="typography108">
                  <div className="cell108">2022-1-12 12:12:32</div>
                </div>
                <div className="loader135">
                  <div className="loader-child249" />
                  <div className="loader-child250" />
                </div>
              </div>
            </div>
            <div className="dividerhorizontal28" />
          </div>
          <div className="tableelementstablecellrow27">
            <div className="tableelementstablecell-parent11">
              <div className="tableelementstablecell108">
                <div className="checkbox29">
                  <input className="padding27" type="checkbox" />
                  <div className="label27">Label</div>
                  <div className="loader136">
                    <div className="loader-child251" />
                    <div className="loader-child252" />
                  </div>
                </div>
                <div className="typography109">
                  <div className="cell109">Paki</div>
                  <div className="loader137">
                    <div className="loader-child253" />
                    <div className="loader-child254" />
                  </div>
                </div>
              </div>
              <div className="tableelementstablecell109">
                <div className="typography110">
                  <div className="cell110">1</div>
                </div>
                <div className="loader138">
                  <div className="loader-child255" />
                  <div className="loader-child256" />
                </div>
              </div>
              <div className="tableelementstablecell110">
                <div className="typography111">
                  <div className="cell111">2022-1-12 12:12:32</div>
                </div>
                <div className="loader139">
                  <div className="loader-child257" />
                  <div className="loader-child258" />
                </div>
              </div>
              <div className="tableelementstablecell111">
                <div className="typography112">
                  <div className="cell112">2022-1-12 12:12:32</div>
                </div>
                <div className="loader140">
                  <div className="loader-child259" />
                  <div className="loader-child260" />
                </div>
              </div>
            </div>
            <div className="dividerhorizontal29" />
          </div>
          <div className="tableelementstablecellrow28">
            <div className="tableelementstablecell-parent12">
              <div className="tableelementstablecell112">
                <div className="checkbox30">
                  <input className="padding28" type="checkbox" />
                  <div className="label28">Label</div>
                  <div className="loader141">
                    <div className="loader-child261" />
                    <div className="loader-child262" />
                  </div>
                </div>
                <div className="typography113">
                  <div className="cell113">Paki</div>
                  <div className="loader142">
                    <div className="loader-child263" />
                    <div className="loader-child264" />
                  </div>
                </div>
              </div>
              <div className="tableelementstablecell113">
                <div className="typography114">
                  <div className="cell114">1</div>
                </div>
                <div className="loader143">
                  <div className="loader-child265" />
                  <div className="loader-child266" />
                </div>
              </div>
              <div className="tableelementstablecell114">
                <div className="typography115">
                  <div className="cell115">2022-1-12 12:12:32</div>
                </div>
                <div className="loader144">
                  <div className="loader-child267" />
                  <div className="loader-child268" />
                </div>
              </div>
              <div className="tableelementstablecell115">
                <div className="typography116">
                  <div className="cell116">2022-1-12 12:12:32</div>
                </div>
                <div className="loader145">
                  <div className="loader-child269" />
                  <div className="loader-child270" />
                </div>
              </div>
            </div>
            <div className="dividerhorizontal30" />
          </div>
          <div className="tableelementstablecellrow29">
            <div className="tableelementstablecell-parent13">
              <div className="tableelementstablecell116">
                <div className="checkbox31">
                  <input className="padding29" type="checkbox" />
                  <div className="label29">Label</div>
                  <div className="loader146">
                    <div className="loader-child271" />
                    <div className="loader-child272" />
                  </div>
                </div>
                <div className="typography117">
                  <div className="cell117">Paki</div>
                  <div className="loader147">
                    <div className="loader-child273" />
                    <div className="loader-child274" />
                  </div>
                </div>
              </div>
              <div className="tableelementstablecell117">
                <div className="typography118">
                  <div className="cell118">1</div>
                </div>
                <div className="loader148">
                  <div className="loader-child275" />
                  <div className="loader-child276" />
                </div>
              </div>
              <div className="tableelementstablecell118">
                <div className="typography119">
                  <div className="cell119">2022-1-12 12:12:32</div>
                </div>
                <div className="loader149">
                  <div className="loader-child277" />
                  <div className="loader-child278" />
                </div>
              </div>
              <div className="tableelementstablecell119">
                <div className="typography120">
                  <div className="cell120">2022-1-12 12:12:32</div>
                </div>
                <div className="loader150">
                  <div className="loader-child279" />
                  <div className="loader-child280" />
                </div>
              </div>
            </div>
            <div className="dividerhorizontal31" />
          </div>
          <div className="tableelementstablecellrow30">
            <div className="tableelementstablecell-parent14">
              <div className="tableelementstablecell120">
                <div className="checkbox32">
                  <input className="padding30" type="checkbox" />
                  <div className="label30">Label</div>
                  <div className="loader151">
                    <div className="loader-child281" />
                    <div className="loader-child282" />
                  </div>
                </div>
                <div className="typography121">
                  <div className="cell121">Paki</div>
                  <div className="loader152">
                    <div className="loader-child283" />
                    <div className="loader-child284" />
                  </div>
                </div>
              </div>
              <div className="tableelementstablecell121">
                <div className="typography122">
                  <div className="cell122">1</div>
                </div>
                <div className="loader153">
                  <div className="loader-child285" />
                  <div className="loader-child286" />
                </div>
              </div>
              <div className="tableelementstablecell122">
                <div className="typography123">
                  <div className="cell123">2022-1-12 12:12:32</div>
                </div>
                <div className="loader154">
                  <div className="loader-child287" />
                  <div className="loader-child288" />
                </div>
              </div>
              <div className="tableelementstablecell123">
                <div className="typography124">
                  <div className="cell124">2022-1-12 12:12:32</div>
                </div>
                <div className="loader155">
                  <div className="loader-child289" />
                  <div className="loader-child290" />
                </div>
              </div>
            </div>
            <div className="dividerhorizontal32" />
          </div>
          <div className="tableelementstablecellrow31">
            <div className="tableelementstablecell-parent15">
              <div className="tableelementstablecell124">
                <div className="checkbox33">
                  <input className="padding31" type="checkbox" />
                  <div className="label31">Label</div>
                  <div className="loader156">
                    <div className="loader-child291" />
                    <div className="loader-child292" />
                  </div>
                </div>
                <div className="typography125">
                  <div className="cell125">Paki</div>
                  <div className="loader157">
                    <div className="loader-child293" />
                    <div className="loader-child294" />
                  </div>
                </div>
              </div>
              <div className="tableelementstablecell125">
                <div className="typography126">
                  <div className="cell126">1</div>
                </div>
                <div className="loader158">
                  <div className="loader-child295" />
                  <div className="loader-child296" />
                </div>
              </div>
              <div className="tableelementstablecell126">
                <div className="typography127">
                  <div className="cell127">2022-1-12 12:12:32</div>
                </div>
                <div className="loader159">
                  <div className="loader-child297" />
                  <div className="loader-child298" />
                </div>
              </div>
              <div className="tableelementstablecell127">
                <div className="typography128">
                  <div className="cell128">2022-1-12 12:12:32</div>
                </div>
                <div className="loader160">
                  <div className="loader-child299" />
                  <div className="loader-child300" />
                </div>
              </div>
            </div>
            <div className="dividerhorizontal33" />
          </div>
          <div className="tableelementstablefooter1">
            <div className="container3">
              <div className="rows-per-page1">Rows per page:</div>
              <div className="page1">
                <div className="div1">16</div>
                <img
                  className="arrowdropdownfilled-icon1"
                  alt=""
                  src="/arrowdropdownfilled.svg"
                />
              </div>
            </div>
            <div className="of-1001">1-5 of 13</div>
            <div className="navigation2">
              <div className="iconbutton2">
                <div className="container4">
                  <img
                    className="chevronleftfilled-icon1"
                    loading="lazy"
                    alt=""
                    src="/chevronleftfilled.svg"
                  />
                </div>
              </div>
              <div className="iconbutton3">
                <div className="container5">
                  <img
                    className="chevronrightfilled-icon1"
                    loading="lazy"
                    alt=""
                    src="/chevronrightfilled.svg"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default LoadCase;
