import MainFrame from "../components/MainFrame";
import NewCaseHalf from "../components/NewCaseHalf";
import Card from "../components/Card";
import "./HomeSearch.css";

const HomeSearch = () => {
  return (
    <div className="home-search">
      <MainFrame rectangleReadCase="Bagdadi" />
      <section className="chip-filled">
        <div className="frame-container">
          <div className="newcase-half-parent">
            <NewCaseHalf new1="New" />
            <div className="newcase-half">
              <div className="newcase-half-child" />
              <div className="arrowcircleright" />
              <div className="new-case-parent">
                <h1 className="new-case">Load Case</h1>
                <img className="vector-icon" alt="" src="/vector.svg" />
              </div>
            </div>
            <div className="loader">
              <div className="nea-feature">
                <h1 className="load-case2">
                  <span className="load-case-txt-container2">
                    <p className="load2">Load</p>
                    <p className="case2">Case</p>
                  </span>
                </h1>
              </div>
              <NewCaseHalf
                new1="Read"
                propMarginLeft="-220px"
                propWidth="220px"
                propAlignSelf="unset"
                propTop="calc(50% - 19px)"
                propBottom="unset"
              />
            </div>
          </div>
          <div className="newcase-full">
            <div className="newcase-full-child" />
            <div className="photo-outlined">
              <h1 className="my-analysis-cases">My Analysis Cases (10+)</h1>
            </div>
            <div className="play-parent">
              <div className="play">
                <div className="mui-table">
                  <div className="tableelementstableheadrow">
                    <div className="frame-header-masked-checkbox-p">
                      <div className="tableelementstablehead">
                        <input className="masked" type="checkbox" />
                        <img
                          className="arrowsdownup-icon"
                          loading="lazy"
                          alt=""
                          src="/arrowsdownup.svg"
                        />
                        <div className="content1">
                          <div className="mask">
                            <img
                              className="arrowdownwardfilled-icon"
                              alt=""
                              src="/arrowdownwardfilled.svg"
                            />
                          </div>
                          <div className="head">Title</div>
                          <div className="mask1">
                            <img
                              className="arrowdownwardfilled-icon1"
                              alt=""
                              src="/arrowdownwardfilled.svg"
                            />
                          </div>
                        </div>
                      </div>
                      <div className="tableelementstablehead1">
                        <div className="mask2">
                          <img
                            className="arrowdownwardfilled-icon2"
                            alt=""
                            src="/arrowdownwardfilled.svg"
                          />
                        </div>
                        <img
                          className="arrowsdownup-icon1"
                          alt=""
                          src="/arrowsdownup.svg"
                        />
                        <div className="head1">Node Count</div>
                        <div className="mask3">
                          <img
                            className="arrowdownwardfilled-icon3"
                            alt=""
                            src="/arrowdownwardfilled.svg"
                          />
                        </div>
                      </div>
                      <div className="tableelementstablehead2">
                        <div className="mask4">
                          <img
                            className="arrowdownwardfilled-icon4"
                            alt=""
                            src="/arrowdownwardfilled.svg"
                          />
                        </div>
                        <img
                          className="arrowsdownup-icon2"
                          alt=""
                          src="/arrowsdownup.svg"
                        />
                        <div className="head2">
                          <span>{`Creation Time `}</span>
                          <span className="utc-530">(UTC +5:30)</span>
                        </div>
                        <div className="mask5">
                          <img
                            className="arrowdownwardfilled-icon5"
                            alt=""
                            src="/arrowdownwardfilled.svg"
                          />
                        </div>
                      </div>
                      <div className="tableelementstablehead3">
                        <div className="mask6">
                          <img
                            className="arrowdownwardfilled-icon6"
                            alt=""
                            src="/arrowdownwardfilled.svg"
                          />
                        </div>
                        <img
                          className="arrowsdownup-icon3"
                          alt=""
                          src="/arrowsdownup.svg"
                        />
                        <div className="head3">
                          <span>{`Last Update `}</span>
                          <span className="utc-5301">(UTC +5:30)</span>
                        </div>
                        <div className="mask7">
                          <img
                            className="arrowdownwardfilled-icon7"
                            alt=""
                            src="/arrowdownwardfilled.svg"
                          />
                        </div>
                      </div>
                    </div>
                    <div className="dividerhorizontal" />
                  </div>
                  <div className="tableelementstablecellrow">
                    <div className="tableelementstablecellrow-inner">
                      <div className="tableelementstablecell-parent">
                        <div className="tableelementstablecell">
                          <div className="checkbox2">
                            <input className="padding" type="checkbox" />
                            <div className="label">Label</div>
                            <div className="loader1">
                              <div className="cell" />
                              <div className="search-result-card" />
                            </div>
                          </div>
                          <div className="typography">
                            <div className="cell1">Paki</div>
                            <div className="loader2">
                              <div className="nea-feature1" />
                              <div className="spacer-vertical" />
                            </div>
                          </div>
                        </div>
                        <div className="tableelementstablecell1">
                          <div className="typography1">
                            <div className="cell2">1</div>
                          </div>
                          <div className="loader3">
                            <div className="loader-child" />
                            <div className="loader-item" />
                          </div>
                        </div>
                        <div className="tableelementstablecell2">
                          <div className="typography2">
                            <div className="cell3">2022-1-12 12:12:32</div>
                          </div>
                          <div className="loader4">
                            <div className="masked-checkbox-cell" />
                            <div className="table-row-elements" />
                          </div>
                        </div>
                        <div className="tableelementstablecell3">
                          <div className="typography3">
                            <div className="cell4">2022-1-12 12:12:32</div>
                          </div>
                          <div className="loader5">
                            <div className="loader-inner" />
                            <div className="frame" />
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="dividerhorizontal1" />
                  </div>
                  <div className="tableelementstablecellrow1">
                    <div className="tableelementstablecellrow-child">
                      <div className="tableelementstablecell-group">
                        <div className="tableelementstablecell4">
                          <div className="checkbox3">
                            <input className="padding1" type="checkbox" />
                            <div className="label1">Label</div>
                            <div className="loader6">
                              <div className="rectangle-div" />
                              <div className="loader-child1" />
                            </div>
                          </div>
                          <div className="typography4">
                            <div className="cell5">Paki</div>
                            <div className="loader7">
                              <div className="loader-child2" />
                              <div className="loader-child3" />
                            </div>
                          </div>
                        </div>
                        <div className="tableelementstablecell5">
                          <div className="typography5">
                            <div className="cell6">1</div>
                          </div>
                          <div className="loader8">
                            <div className="loader-child4" />
                            <div className="loader-child5" />
                          </div>
                        </div>
                        <div className="tableelementstablecell6">
                          <div className="typography6">
                            <div className="cell7">2022-1-12 12:12:32</div>
                          </div>
                          <div className="loader9">
                            <div className="loader-child6" />
                            <div className="loader-child7" />
                          </div>
                        </div>
                        <div className="tableelementstablecell7">
                          <div className="typography7">
                            <div className="cell8">2022-1-12 12:12:32</div>
                          </div>
                          <div className="loader10">
                            <div className="loader-child8" />
                            <div className="loader-child9" />
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="dividerhorizontal2" />
                  </div>
                  <div className="tableelementstablecellrow2">
                    <div className="frame-div">
                      <div className="tableelementstablecell-container">
                        <div className="tableelementstablecell8">
                          <div className="checkbox4">
                            <input className="padding2" type="checkbox" />
                            <div className="label2">Label</div>
                            <div className="loader11">
                              <div className="loader-child10" />
                              <div className="loader-child11" />
                            </div>
                          </div>
                          <div className="typography8">
                            <div className="cell9">Paki</div>
                            <div className="loader12">
                              <div className="loader-child12" />
                              <div className="loader-child13" />
                            </div>
                          </div>
                        </div>
                        <div className="tableelementstablecell9">
                          <div className="typography9">
                            <div className="cell10">1</div>
                          </div>
                          <div className="loader13">
                            <div className="loader-child14" />
                            <div className="loader-child15" />
                          </div>
                        </div>
                        <div className="tableelementstablecell10">
                          <div className="typography10">
                            <div className="cell11">2022-1-12 12:12:32</div>
                          </div>
                          <div className="loader14">
                            <div className="loader-child16" />
                            <div className="loader-child17" />
                          </div>
                        </div>
                        <div className="tableelementstablecell11">
                          <div className="typography11">
                            <div className="cell12">2022-1-12 12:12:32</div>
                          </div>
                          <div className="loader15">
                            <div className="loader-child18" />
                            <div className="loader-child19" />
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="dividerhorizontal3" />
                  </div>
                  <div className="tableelementstablecellrow3">
                    <div className="tableelementstablecell12">
                      <div className="checkbox5">
                        <div className="padding3">
                          <img
                            className="checkboxoutlineblankoutlined-icon"
                            alt=""
                            src="/checkboxoutlineblankoutlined-4.svg"
                          />
                        </div>
                        <div className="label3">Label</div>
                        <div className="loader16">
                          <div className="loader-child20" />
                          <div className="loader-child21" />
                        </div>
                      </div>
                      <div className="typography12">
                        <div className="cell13">Paki</div>
                        <div className="loader17">
                          <div className="loader-child22" />
                          <div className="loader-child23" />
                        </div>
                      </div>
                    </div>
                    <div className="tableelementstablecell13">
                      <div className="typography13">
                        <div className="cell14">1</div>
                      </div>
                      <div className="loader18">
                        <div className="loader-child24" />
                        <div className="loader-child25" />
                      </div>
                    </div>
                    <div className="tableelementstablecell14">
                      <div className="typography14">
                        <div className="cell15">2022-1-12 12:12:32</div>
                      </div>
                      <div className="loader19">
                        <div className="loader-child26" />
                        <div className="loader-child27" />
                      </div>
                    </div>
                    <div className="tableelementstablecell15">
                      <div className="typography15">
                        <div className="cell16">2022-1-12 12:12:32</div>
                      </div>
                      <div className="loader20">
                        <div className="loader-child28" />
                        <div className="loader-child29" />
                      </div>
                    </div>
                    <div className="dividerhorizontal4" />
                  </div>
                  <div className="tableelementstablecellrow4">
                    <div className="tableelementstablecell16">
                      <div className="checkbox6">
                        <div className="padding4">
                          <img
                            className="checkboxoutlineblankoutlined-icon1"
                            alt=""
                            src="/checkboxoutlineblankoutlined-4.svg"
                          />
                        </div>
                        <div className="label4">Label</div>
                        <div className="loader21">
                          <div className="loader-child30" />
                          <div className="loader-child31" />
                        </div>
                      </div>
                      <div className="typography16">
                        <div className="cell17">Paki</div>
                        <div className="loader22">
                          <div className="loader-child32" />
                          <div className="loader-child33" />
                        </div>
                      </div>
                    </div>
                    <div className="tableelementstablecell17">
                      <div className="typography17">
                        <div className="cell18">1</div>
                      </div>
                      <div className="loader23">
                        <div className="loader-child34" />
                        <div className="loader-child35" />
                      </div>
                    </div>
                    <div className="tableelementstablecell18">
                      <div className="typography18">
                        <div className="cell19">2022-1-12 12:12:32</div>
                      </div>
                      <div className="loader24">
                        <div className="loader-child36" />
                        <div className="loader-child37" />
                      </div>
                    </div>
                    <div className="tableelementstablecell19">
                      <div className="typography19">
                        <div className="cell20">2022-1-12 12:12:32</div>
                      </div>
                      <div className="loader25">
                        <div className="loader-child38" />
                        <div className="loader-child39" />
                      </div>
                    </div>
                    <div className="dividerhorizontal5" />
                  </div>
                  <div className="tableelementstablecellrow5">
                    <div className="tableelementstablecell20">
                      <div className="checkbox7">
                        <div className="padding5">
                          <img
                            className="checkboxoutlineblankoutlined-icon2"
                            alt=""
                            src="/checkboxoutlineblankoutlined-4.svg"
                          />
                        </div>
                        <div className="label5">Label</div>
                        <div className="loader26">
                          <div className="loader-child40" />
                          <div className="loader-child41" />
                        </div>
                      </div>
                      <div className="typography20">
                        <div className="cell21">Paki</div>
                        <div className="loader27">
                          <div className="loader-child42" />
                          <div className="loader-child43" />
                        </div>
                      </div>
                    </div>
                    <div className="tableelementstablecell21">
                      <div className="typography21">
                        <div className="cell22">1</div>
                      </div>
                      <div className="loader28">
                        <div className="loader-child44" />
                        <div className="loader-child45" />
                      </div>
                    </div>
                    <div className="tableelementstablecell22">
                      <div className="typography22">
                        <div className="cell23">2022-1-12 12:12:32</div>
                      </div>
                      <div className="loader29">
                        <div className="loader-child46" />
                        <div className="loader-child47" />
                      </div>
                    </div>
                    <div className="tableelementstablecell23">
                      <div className="typography23">
                        <div className="cell24">2022-1-12 12:12:32</div>
                      </div>
                      <div className="loader30">
                        <div className="loader-child48" />
                        <div className="loader-child49" />
                      </div>
                    </div>
                    <div className="dividerhorizontal6" />
                  </div>
                  <div className="tableelementstablecellrow6">
                    <div className="tableelementstablecell24">
                      <div className="checkbox8">
                        <div className="padding6">
                          <img
                            className="checkboxoutlineblankoutlined-icon3"
                            alt=""
                            src="/checkboxoutlineblankoutlined-4.svg"
                          />
                        </div>
                        <div className="label6">Label</div>
                        <div className="loader31">
                          <div className="loader-child50" />
                          <div className="loader-child51" />
                        </div>
                      </div>
                      <div className="typography24">
                        <div className="cell25">Paki</div>
                        <div className="loader32">
                          <div className="loader-child52" />
                          <div className="loader-child53" />
                        </div>
                      </div>
                    </div>
                    <div className="tableelementstablecell25">
                      <div className="typography25">
                        <div className="cell26">1</div>
                      </div>
                      <div className="loader33">
                        <div className="loader-child54" />
                        <div className="loader-child55" />
                      </div>
                    </div>
                    <div className="tableelementstablecell26">
                      <div className="typography26">
                        <div className="cell27">2022-1-12 12:12:32</div>
                      </div>
                      <div className="loader34">
                        <div className="loader-child56" />
                        <div className="loader-child57" />
                      </div>
                    </div>
                    <div className="tableelementstablecell27">
                      <div className="typography27">
                        <div className="cell28">2022-1-12 12:12:32</div>
                      </div>
                      <div className="loader35">
                        <div className="loader-child58" />
                        <div className="loader-child59" />
                      </div>
                    </div>
                    <div className="dividerhorizontal7" />
                  </div>
                  <div className="tableelementstablecellrow7">
                    <div className="tableelementstablecell28">
                      <div className="checkbox9">
                        <div className="padding7">
                          <img
                            className="checkboxoutlineblankoutlined-icon4"
                            alt=""
                            src="/checkboxoutlineblankoutlined-4.svg"
                          />
                        </div>
                        <div className="label7">Label</div>
                        <div className="loader36">
                          <div className="loader-child60" />
                          <div className="loader-child61" />
                        </div>
                      </div>
                      <div className="typography28">
                        <div className="cell29">Paki</div>
                        <div className="loader37">
                          <div className="loader-child62" />
                          <div className="loader-child63" />
                        </div>
                      </div>
                    </div>
                    <div className="tableelementstablecell29">
                      <div className="typography29">
                        <div className="cell30">1</div>
                      </div>
                      <div className="loader38">
                        <div className="loader-child64" />
                        <div className="loader-child65" />
                      </div>
                    </div>
                    <div className="tableelementstablecell30">
                      <div className="typography30">
                        <div className="cell31">2022-1-12 12:12:32</div>
                      </div>
                      <div className="loader39">
                        <div className="loader-child66" />
                        <div className="loader-child67" />
                      </div>
                    </div>
                    <div className="tableelementstablecell31">
                      <div className="typography31">
                        <div className="cell32">2022-1-12 12:12:32</div>
                      </div>
                      <div className="loader40">
                        <div className="loader-child68" />
                        <div className="loader-child69" />
                      </div>
                    </div>
                    <div className="dividerhorizontal8" />
                  </div>
                  <div className="tableelementstablecellrow8">
                    <div className="tableelementstablecell32">
                      <div className="checkbox10">
                        <div className="padding8">
                          <img
                            className="checkboxoutlineblankoutlined-icon5"
                            alt=""
                            src="/checkboxoutlineblankoutlined-4.svg"
                          />
                        </div>
                        <div className="label8">Label</div>
                        <div className="loader41">
                          <div className="loader-child70" />
                          <div className="loader-child71" />
                        </div>
                      </div>
                      <div className="typography32">
                        <div className="cell33">Paki</div>
                        <div className="loader42">
                          <div className="loader-child72" />
                          <div className="loader-child73" />
                        </div>
                      </div>
                    </div>
                    <div className="tableelementstablecell33">
                      <div className="typography33">
                        <div className="cell34">1</div>
                      </div>
                      <div className="loader43">
                        <div className="loader-child74" />
                        <div className="loader-child75" />
                      </div>
                    </div>
                    <div className="tableelementstablecell34">
                      <div className="typography34">
                        <div className="cell35">2022-1-12 12:12:32</div>
                      </div>
                      <div className="loader44">
                        <div className="loader-child76" />
                        <div className="loader-child77" />
                      </div>
                    </div>
                    <div className="tableelementstablecell35">
                      <div className="typography35">
                        <div className="cell36">2022-1-12 12:12:32</div>
                      </div>
                      <div className="loader45">
                        <div className="loader-child78" />
                        <div className="loader-child79" />
                      </div>
                    </div>
                    <div className="dividerhorizontal9" />
                  </div>
                  <div className="tableelementstablecellrow9">
                    <div className="tableelementstablecell36">
                      <div className="checkbox11">
                        <div className="padding9">
                          <img
                            className="checkboxoutlineblankoutlined-icon6"
                            alt=""
                            src="/checkboxoutlineblankoutlined-4.svg"
                          />
                        </div>
                        <div className="label9">Label</div>
                        <div className="loader46">
                          <div className="loader-child80" />
                          <div className="loader-child81" />
                        </div>
                      </div>
                      <div className="typography36">
                        <div className="cell37">Paki</div>
                        <div className="loader47">
                          <div className="loader-child82" />
                          <div className="loader-child83" />
                        </div>
                      </div>
                    </div>
                    <div className="tableelementstablecell37">
                      <div className="typography37">
                        <div className="cell38">1</div>
                      </div>
                      <div className="loader48">
                        <div className="loader-child84" />
                        <div className="loader-child85" />
                      </div>
                    </div>
                    <div className="tableelementstablecell38">
                      <div className="typography38">
                        <div className="cell39">2022-1-12 12:12:32</div>
                      </div>
                      <div className="loader49">
                        <div className="loader-child86" />
                        <div className="loader-child87" />
                      </div>
                    </div>
                    <div className="tableelementstablecell39">
                      <div className="typography39">
                        <div className="cell40">2022-1-12 12:12:32</div>
                      </div>
                      <div className="loader50">
                        <div className="loader-child88" />
                        <div className="loader-child89" />
                      </div>
                    </div>
                    <div className="dividerhorizontal10" />
                  </div>
                  <div className="tableelementstablecellrow10">
                    <div className="tableelementstablecell40">
                      <div className="checkbox12">
                        <div className="padding10">
                          <img
                            className="checkboxoutlineblankoutlined-icon7"
                            alt=""
                            src="/checkboxoutlineblankoutlined-4.svg"
                          />
                        </div>
                        <div className="label10">Label</div>
                        <div className="loader51">
                          <div className="loader-child90" />
                          <div className="loader-child91" />
                        </div>
                      </div>
                      <div className="typography40">
                        <div className="cell41">Paki</div>
                        <div className="loader52">
                          <div className="loader-child92" />
                          <div className="loader-child93" />
                        </div>
                      </div>
                    </div>
                    <div className="tableelementstablecell41">
                      <div className="typography41">
                        <div className="cell42">1</div>
                      </div>
                      <div className="loader53">
                        <div className="loader-child94" />
                        <div className="loader-child95" />
                      </div>
                    </div>
                    <div className="tableelementstablecell42">
                      <div className="typography42">
                        <div className="cell43">2022-1-12 12:12:32</div>
                      </div>
                      <div className="loader54">
                        <div className="loader-child96" />
                        <div className="loader-child97" />
                      </div>
                    </div>
                    <div className="tableelementstablecell43">
                      <div className="typography43">
                        <div className="cell44">2022-1-12 12:12:32</div>
                      </div>
                      <div className="loader55">
                        <div className="loader-child98" />
                        <div className="loader-child99" />
                      </div>
                    </div>
                    <div className="dividerhorizontal11" />
                  </div>
                  <div className="tableelementstablecellrow11">
                    <div className="tableelementstablecell44">
                      <div className="checkbox13">
                        <div className="padding11">
                          <img
                            className="checkboxoutlineblankoutlined-icon8"
                            alt=""
                            src="/checkboxoutlineblankoutlined-4.svg"
                          />
                        </div>
                        <div className="label11">Label</div>
                        <div className="loader56">
                          <div className="loader-child100" />
                          <div className="loader-child101" />
                        </div>
                      </div>
                      <div className="typography44">
                        <div className="cell45">Paki</div>
                        <div className="loader57">
                          <div className="loader-child102" />
                          <div className="loader-child103" />
                        </div>
                      </div>
                    </div>
                    <div className="tableelementstablecell45">
                      <div className="typography45">
                        <div className="cell46">1</div>
                      </div>
                      <div className="loader58">
                        <div className="loader-child104" />
                        <div className="loader-child105" />
                      </div>
                    </div>
                    <div className="tableelementstablecell46">
                      <div className="typography46">
                        <div className="cell47">2022-1-12 12:12:32</div>
                      </div>
                      <div className="loader59">
                        <div className="loader-child106" />
                        <div className="loader-child107" />
                      </div>
                    </div>
                    <div className="tableelementstablecell47">
                      <div className="typography47">
                        <div className="cell48">2022-1-12 12:12:32</div>
                      </div>
                      <div className="loader60">
                        <div className="loader-child108" />
                        <div className="loader-child109" />
                      </div>
                    </div>
                    <div className="dividerhorizontal12" />
                  </div>
                  <div className="tableelementstablecellrow12">
                    <div className="tableelementstablecell48">
                      <div className="checkbox14">
                        <div className="padding12">
                          <img
                            className="checkboxoutlineblankoutlined-icon9"
                            alt=""
                            src="/checkboxoutlineblankoutlined-4.svg"
                          />
                        </div>
                        <div className="label12">Label</div>
                        <div className="loader61">
                          <div className="loader-child110" />
                          <div className="loader-child111" />
                        </div>
                      </div>
                      <div className="typography48">
                        <div className="cell49">Paki</div>
                        <div className="loader62">
                          <div className="loader-child112" />
                          <div className="loader-child113" />
                        </div>
                      </div>
                    </div>
                    <div className="tableelementstablecell49">
                      <div className="typography49">
                        <div className="cell50">1</div>
                      </div>
                      <div className="loader63">
                        <div className="loader-child114" />
                        <div className="loader-child115" />
                      </div>
                    </div>
                    <div className="tableelementstablecell50">
                      <div className="typography50">
                        <div className="cell51">2022-1-12 12:12:32</div>
                      </div>
                      <div className="loader64">
                        <div className="loader-child116" />
                        <div className="loader-child117" />
                      </div>
                    </div>
                    <div className="tableelementstablecell51">
                      <div className="typography51">
                        <div className="cell52">2022-1-12 12:12:32</div>
                      </div>
                      <div className="loader65">
                        <div className="loader-child118" />
                        <div className="loader-child119" />
                      </div>
                    </div>
                    <div className="dividerhorizontal13" />
                  </div>
                  <div className="tableelementstablecellrow13">
                    <div className="tableelementstablecell52">
                      <div className="checkbox15">
                        <div className="padding13">
                          <img
                            className="checkboxoutlineblankoutlined-icon10"
                            alt=""
                            src="/checkboxoutlineblankoutlined-4.svg"
                          />
                        </div>
                        <div className="label13">Label</div>
                        <div className="loader66">
                          <div className="loader-child120" />
                          <div className="loader-child121" />
                        </div>
                      </div>
                      <div className="typography52">
                        <div className="cell53">Paki</div>
                        <div className="loader67">
                          <div className="loader-child122" />
                          <div className="loader-child123" />
                        </div>
                      </div>
                    </div>
                    <div className="tableelementstablecell53">
                      <div className="typography53">
                        <div className="cell54">1</div>
                      </div>
                      <div className="loader68">
                        <div className="loader-child124" />
                        <div className="loader-child125" />
                      </div>
                    </div>
                    <div className="tableelementstablecell54">
                      <div className="typography54">
                        <div className="cell55">2022-1-12 12:12:32</div>
                      </div>
                      <div className="loader69">
                        <div className="loader-child126" />
                        <div className="loader-child127" />
                      </div>
                    </div>
                    <div className="tableelementstablecell55">
                      <div className="typography55">
                        <div className="cell56">2022-1-12 12:12:32</div>
                      </div>
                      <div className="loader70">
                        <div className="loader-child128" />
                        <div className="loader-child129" />
                      </div>
                    </div>
                    <div className="dividerhorizontal14" />
                  </div>
                  <div className="tableelementstablecellrow14">
                    <div className="tableelementstablecell56">
                      <div className="checkbox16">
                        <input className="padding14" type="checkbox" />
                        <div className="label14">Label</div>
                        <div className="loader71">
                          <div className="loader-child130" />
                          <div className="loader-child131" />
                        </div>
                      </div>
                      <div className="typography56">
                        <div className="cell57">Paki</div>
                        <div className="loader72">
                          <div className="loader-child132" />
                          <div className="loader-child133" />
                        </div>
                      </div>
                    </div>
                    <div className="tableelementstablecell57">
                      <div className="typography57">
                        <div className="cell58">1</div>
                      </div>
                      <div className="loader73">
                        <div className="loader-child134" />
                        <div className="loader-child135" />
                      </div>
                    </div>
                    <div className="tableelementstablecell58">
                      <div className="typography58">
                        <div className="cell59">2022-1-12 12:12:32</div>
                      </div>
                      <div className="loader74">
                        <div className="loader-child136" />
                        <div className="loader-child137" />
                      </div>
                    </div>
                    <div className="tableelementstablecell59">
                      <div className="typography59">
                        <div className="cell60">2022-1-12 12:12:32</div>
                      </div>
                      <div className="loader75">
                        <div className="loader-child138" />
                        <div className="loader-child139" />
                      </div>
                    </div>
                    <div className="dividerhorizontal15" />
                  </div>
                  <div className="tableelementstablecellrow15">
                    <div className="tableelementstablecell60">
                      <div className="checkbox17">
                        <div className="padding15">
                          <img
                            className="checkboxoutlineblankoutlined-icon11"
                            alt=""
                            src="/checkboxoutlineblankoutlined-4.svg"
                          />
                        </div>
                        <div className="label15">Label</div>
                        <div className="loader76">
                          <div className="loader-child140" />
                          <div className="loader-child141" />
                        </div>
                      </div>
                      <div className="typography60">
                        <div className="cell61">Paki</div>
                        <div className="loader77">
                          <div className="loader-child142" />
                          <div className="loader-child143" />
                        </div>
                      </div>
                    </div>
                    <div className="tableelementstablecell61">
                      <div className="typography61">
                        <div className="cell62">1</div>
                      </div>
                      <div className="loader78">
                        <div className="loader-child144" />
                        <div className="loader-child145" />
                      </div>
                    </div>
                    <div className="tableelementstablecell62">
                      <div className="typography62">
                        <div className="cell63">2022-1-12 12:12:32</div>
                      </div>
                      <div className="loader79">
                        <div className="loader-child146" />
                        <div className="loader-child147" />
                      </div>
                    </div>
                    <div className="tableelementstablecell63">
                      <div className="typography63">
                        <div className="cell64">2022-1-12 12:12:32</div>
                      </div>
                      <div className="loader80">
                        <div className="loader-child148" />
                        <div className="loader-child149" />
                      </div>
                    </div>
                    <div className="dividerhorizontal16" />
                  </div>
                  <div className="tableelementstablefooter">
                    <div className="container">
                      <div className="rows-per-page">Rows per page:</div>
                      <div className="page">
                        <div className="div">16</div>
                        <img
                          className="arrowdropdownfilled-icon"
                          alt=""
                          src="/arrowdropdownfilled.svg"
                        />
                      </div>
                    </div>
                    <div className="of-100">1-5 of 13</div>
                    <div className="navigation">
                      <div className="iconbutton">
                        <div className="container1">
                          <img
                            className="chevronleftfilled-icon"
                            alt=""
                            src="/chevronleftfilled.svg"
                          />
                        </div>
                      </div>
                      <div className="iconbutton1">
                        <div className="container2">
                          <img
                            className="chevronrightfilled-icon"
                            alt=""
                            src="/chevronrightfilled.svg"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="frame-content">
                  <div className="card-list-container" />
                </div>
              </div>
              <div className="search-result-frame">
                <h1 className="search-result-10">Search Result (10+)</h1>
              </div>
            </div>
            <div className="blog-post-item">
              <div className="card-blog-posts-placeholder-im">
                <div className="blog-list">
                  <Card />
                  <Card />
                  <Card />
                </div>
                <div className="placeholder-loader-wrapper">
                  <div className="placeholder-loader" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomeSearch;
