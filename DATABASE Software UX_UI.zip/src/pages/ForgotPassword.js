import { useCallback } from "react";
import { Button } from "@mui/material";
import Input from "../components/Input";
import { useNavigate } from "react-router-dom";
import "./ForgotPassword.css";

const ForgotPassword = () => {
  const navigate = useNavigate();

  const onButtonsClick = useCallback(() => {
    navigate("/log-in");
  }, [navigate]);

  return (
    <div className="forgot-password">
      <section className="parent-frame">
        <div className="parent-frame-inner">
          <div className="frame-parent">
            <div className="frame-group">
              <div className="friday-intel-wordmark-black-parent">
                <img
                  className="friday-intel-wordmark-black"
                  loading="lazy"
                  alt=""
                  src="/friday-intel-wordmark-black.svg"
                />
                <img
                  className="darllight-mode-icon"
                  loading="lazy"
                  alt=""
                  src="/darllight-mode@2x.png"
                />
              </div>
              <div className="parent-form-frame">
                <div className="forgotpassword">
                  <div className="section-title">
                    <h1 className="forgot-password1">Forgot Password</h1>
                    <div className="please-enter-registered">
                      Please enter registered Email/ Mobile number to receive a
                      OTP
                    </div>
                  </div>
                  <div className="form">
                    <Input />
                    <Button
                      className="buttons"
                      disableElevation={true}
                      variant="outlined"
                      sx={{
                        textTransform: "none",
                        color: "#fff",
                        fontSize: "12",
                        borderColor: "#fff",
                        borderRadius: "14px",
                        "&:hover": { borderColor: "#fff" },
                        height: 45,
                      }}
                      onClick={onButtonsClick}
                    >
                      Reset Password
                    </Button>
                    <div className="links">
                      <div className="dont-have-an">Wanna try again?</div>
                      <div className="contact-us">Log in</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="friday-intel-pvt">
              © 2022-23 Friday Intel Pvt. Ltd.
            </div>
          </div>
        </div>
        <div className="placeholder-image">
          <img
            className="placeholder-image1"
            loading="lazy"
            alt=""
            src="/placeholder--image@2x.png"
          />
        </div>
      </section>
      <div className="friday-intel-pvt-ltd-wrapper">
        <div className="friday-intel-pvt1">© 2022 Friday Intel Pvt. Ltd.</div>
      </div>
    </div>
  );
};

export default ForgotPassword;
