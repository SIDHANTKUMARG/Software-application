import ReadCaseVariant from "../components/ReadCaseVariant";
import "./LandingPage.css";

const LandingPage = () => {
  return (
    <div className="landing-page">
      <ReadCaseVariant />
    </div>
  );
};

export default LandingPage;
