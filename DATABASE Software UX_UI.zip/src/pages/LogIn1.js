import LoginContainer from "../components/LoginContainer";
import "./LogIn1.css";

const LogIn1 = () => {
  return (
    <div className="log-in1">
      <section className="frame-login">
        <LoginContainer />
        <div className="placeholder-image-frame">
          <img
            className="placeholder-image3"
            loading="lazy"
            alt=""
            src="/placeholder--image1@2x.png"
          />
        </div>
      </section>
      <div className="secondary-frame">
        <div className="friday-intel-pvt3">© 2022 Friday Intel Pvt. Ltd.</div>
      </div>
    </div>
  );
};

export default LogIn1;
