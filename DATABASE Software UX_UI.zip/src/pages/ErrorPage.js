import { Button } from "@mui/material";
import MainFRAME1 from "../components/MainFRAME1";
import "./ErrorPage.css";

const ErrorPage = () => {
  return (
    <div className="error-page">
      <MainFRAME1 />
      <section className="error-message-f-r-a-m-e">
        <div className="back-to-dashboard-b-u-t-t-o-n">
          <div className="error-s-v-g-f-r-a-m-e">
            <div className="main-f-r-a-m-e-e-r-r-o-r">
              <div className="error-message">
                <h1 className="oops">Oops!</h1>
              </div>
              <div className="the-page-you">
                The page you were looking for doesn’t exist.
              </div>
            </div>
          </div>
          <div className="load-case-label">
            <div className="buttons-section">
              <div className="load-case7">
                <span className="load-case-txt-container5">
                  <p className="load5">Load</p>
                  <p className="case6">Case</p>
                </span>
              </div>
            </div>
            <div className="edit-button">
              <Button
                className="buttons-sec"
                disableElevation={true}
                variant="outlined"
                sx={{
                  textTransform: "none",
                  color: "#fff",
                  fontSize: "12",
                  borderColor: "#fff",
                  borderRadius: "14px",
                  "&:hover": { borderColor: "#fff" },
                  height: 39,
                }}
              >
                Back To Dashboard
              </Button>
              <img
                className="error-svg-icon"
                loading="lazy"
                alt=""
                src="/404-error-svg.svg"
              />
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default ErrorPage;
