import { useEffect } from "react";
import {
  Routes,
  Route,
  useNavigationType,
  useLocation,
} from "react-router-dom";
import ForgotPassword from "./pages/ForgotPassword";
import LogIn from "./pages/LogIn";
import LogIn1 from "./pages/LogIn1";
import HomeSearch from "./pages/HomeSearch";
import FINewCase from "./pages/FINewCase";
import LoadCase from "./pages/LoadCase";
import LandingPage from "./pages/LandingPage";
import ErrorPage from "./pages/ErrorPage";
import MobileCompatibleWhite from "./pages/MobileCompatibleWhite";

function App() {
  const action = useNavigationType();
  const location = useLocation();
  const pathname = location.pathname;

  useEffect(() => {
    if (action !== "POP") {
      window.scrollTo(0, 0);
    }
  }, [action, pathname]);

  useEffect(() => {
    let title = "";
    let metaDescription = "";

    switch (pathname) {
      case "/":
        title = "";
        metaDescription = "";
        break;
      case "/log-in":
        title = "";
        metaDescription = "";
        break;
      case "/log-in1":
        title = "";
        metaDescription = "";
        break;
      case "/home-search":
        title = "";
        metaDescription = "";
        break;
      case "/fi-new-case":
        title = "";
        metaDescription = "";
        break;
      case "/load-case":
        title = "";
        metaDescription = "";
        break;
      case "/landing-page":
        title = "";
        metaDescription = "";
        break;
      case "/error-page":
        title = "";
        metaDescription = "";
        break;
      case "/mobile-compatible-white":
        title = "";
        metaDescription = "";
        break;
    }

    if (title) {
      document.title = title;
    }

    if (metaDescription) {
      const metaDescriptionTag = document.querySelector(
        'head > meta[name="description"]'
      );
      if (metaDescriptionTag) {
        metaDescriptionTag.content = metaDescription;
      }
    }
  }, [pathname]);

  return (
    <Routes>
      <Route path="/" element={<ForgotPassword />} />
      <Route path="/log-in" element={<LogIn />} />
      <Route path="/log-in1" element={<LogIn1 />} />
      <Route path="/home-search" element={<HomeSearch />} />
      <Route path="/fi-new-case" element={<FINewCase />} />
      <Route path="/load-case" element={<LoadCase />} />
      <Route path="/landing-page" element={<LandingPage />} />
      <Route path="/error-page" element={<ErrorPage />} />
      <Route
        path="/mobile-compatible-white"
        element={<MobileCompatibleWhite />}
      />
    </Routes>
  );
}
export default App;
