import { useCallback } from "react";
import { TextField, InputAdornment, Icon, IconButton } from "@mui/material";
import Input from "./Input";
import { useNavigate } from "react-router-dom";
import "./LoginContainer.css";

const LoginContainer = () => {
  const navigate = useNavigate();

  const onForgotPasswordTextClick = useCallback(() => {
    navigate("/forgot-password");
  }, [navigate]);

  return (
    <div className="login-content">
      <div className="navbar-frame">
        <img className="navbar-icon1" alt="" src="/navbar.svg" />
        <img
          className="darllight-mode-icon3"
          loading="lazy"
          alt=""
          src="/darllight-mode1@2x.png"
        />
      </div>
      <div className="frame-input">
        <div className="email-field">
          <div className="input-email">
            <h1 className="welcome-back1">Welcome back</h1>
            <div className="please-enter-your1">
              Please enter your login credentials.
            </div>
          </div>
          <div className="frame-login-error">
            <Input
              propAlignSelf="stretch"
              propWidth="unset"
              propWidth1="142px"
            />
            <div className="frame-checkbox">
              <div className="password1">Password</div>
              <TextField
                className="input2"
                placeholder="*********"
                variant="outlined"
                sx={{
                  "& fieldset": { borderColor: "#d7d7d7" },
                  "& .MuiInputBase-root": {
                    height: "48px",
                    backgroundColor: "#fff",
                    borderRadius: "8px",
                    fontSize: "12px",
                  },
                  "& .MuiInputBase-input": { color: "rgba(43, 43, 43, 0.5)" },
                }}
              />
              <div className="wrongpass">
                <div className="wrong-username-or">
                  Wrong Username or Password! Enter valid credentials.
                </div>
              </div>
            </div>
            <div className="content5">
              <div className="checkbox-container">
                <input className="checkbox51" type="checkbox" />
                <div className="remember-me1">Remember me</div>
              </div>
              <div
                className="forgot-password3"
                onClick={onForgotPasswordTextClick}
              >
                Forgot password
              </div>
            </div>
            <TextField
              className="buttons-primary1"
              placeholder="Login"
              variant="outlined"
              InputProps={{
                endAdornment: (
                  <img width="18px" height="18px" src="/arrowright.svg" />
                ),
              }}
              sx={{
                "& fieldset": { border: "none" },
                "& .MuiInputBase-root": {
                  height: "45px",
                  backgroundColor: "rgba(28, 28, 28, 0.7)",
                  paddingRight: "168px",
                  borderRadius: "14px",
                  fontSize: "14px",
                },
                "& .MuiInputBase-input": { color: "#fff" },
              }}
            />
            <div className="links3">
              <div className="dont-have-an3">Don’t have an account ?</div>
              <div className="contact-us3">Contact Us</div>
            </div>
          </div>
        </div>
      </div>
      <div className="friday-intel-pvt6">© 2022-23 Friday Intel Pvt. Ltd.</div>
    </div>
  );
};

export default LoginContainer;
