import "./BottomBar.css";

const BottomBar = () => {
  return (
    <div className="bottom-bar3">
      <div className="searchmini">
        <div className="u-r-l-check">
          <div className="try">
            <div className="try-child" />
            <div className="url-check">URL Check</div>
          </div>
        </div>
        <div className="canvas-tools-onhover1">
          <div className="footer-icons3" />
          <div className="canvas-tools1">
            <div className="fullscreen-icon1">
              <div className="magnify-i-n-icon" />
              <img
                className="arrowsoutcardinal-icon2"
                alt=""
                src="/arrowsoutcardinal-1@2x.png"
              />
            </div>
            <img
              className="magnifyin-icon1"
              loading="lazy"
              alt=""
              src="/magnifyinicon@2x.png"
            />
            <img
              className="magnifyout-icon1"
              loading="lazy"
              alt=""
              src="/magnifyouticon@2x.png"
            />
            <div className="target-icon3">
              <div className="target-icon-item" />
              <img
                className="target-icon4"
                loading="lazy"
                alt=""
                src="/target.svg"
              />
            </div>
            <img
              className="layout-icon1"
              loading="lazy"
              alt=""
              src="/layouticon@2x.png"
            />
            <img
              className="tree-icon1"
              loading="lazy"
              alt=""
              src="/treeicon@2x.png"
            />
            <img
              className="snapshot-icon3"
              loading="lazy"
              alt=""
              src="/snapshoticon@2x.png"
            />
            <img
              className="snapshot-icon4"
              alt=""
              src="/snapshoticon-1@2x.png"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default BottomBar;
