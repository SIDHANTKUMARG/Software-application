import "./NewCaseHalf1.css";

const NewCaseHalf1 = ({ new1 }) => {
  return (
    <div className="newcase-half2">
      <div className="newcase-half-item" />
      <div className="arrowcircleright4" />
      <h1 className="new-case4">
        <span className="new-case-txt-container1">
          <p className="new1">{new1}</p>
          <p className="case8">Case</p>
        </span>
      </h1>
      <img className="vector-icon2" loading="lazy" alt="" src="/vector.svg" />
    </div>
  );
};

export default NewCaseHalf1;
