import { TextField, InputAdornment, Icon, IconButton } from "@mui/material";
import "./Card.css";

const Card = () => {
  return (
    <div className="card">
      <div className="blogpostsplaceholderimage">
        <div className="placeholderimage" />
        <div className="loader161">
          <div className="loader-photo" />
          <div className="rectangles" />
        </div>
        <img
          className="photooutlined-icon"
          loading="lazy"
          alt=""
          src="/photooutlined.svg"
        />
        <div className="iconbutton6">
          <div className="loader162">
            <div className="rectangles1" />
            <div className="rectangles2" />
          </div>
          <div className="container9">
            <img className="play-icon" loading="lazy" alt="" src="/play.svg" />
          </div>
        </div>
      </div>
      <div className="cardelementscardheader">
        <div className="content6">
          <div className="card-header">Card header</div>
          <div className="subheader">Subheader</div>
        </div>
        <div className="iconbutton7">
          <div className="container10">
            <img className="starfilled-icon" alt="" src="/starfilled.svg" />
          </div>
        </div>
      </div>
      <div className="dividerhorizontal51" />
      <div className="cardelementscardcontent">
        <div className="card-content-frame">
          <div className="inner-blog-post-card-content">
            <div className="feature-nea-available">
              <div className="blogpostcardcontent">
                <div className="john-doe">John Doe • 4 Feb 2022</div>
                <div className="spacervertical">
                  <div className="frame2">
                    <div className="spacer" />
                  </div>
                </div>
                <div className="unused-placeholder-image">
                  <div className="nea-feature-avaialbe">
                    Nea feature avaialbe on Zalter
                  </div>
                  <div className="spacervertical1">
                    <div className="frame3">
                      <div className="spacer1" />
                    </div>
                  </div>
                </div>
                <div className="it-is-a">
                  It is a long established fact that a reader will be distracted
                  by the readable content of a page when looking at its layout.
                </div>
                <div className="unused-placeholder-image1">
                  <div className="spacervertical2">
                    <div className="frame4">
                      <div className="spacer2" />
                    </div>
                  </div>
                  <div className="container11">
                    <div className="chipfilled">
                      <div className="container12">
                        <div className="avatar">
                          <div className="avatar1">
                            <div className="op">OP</div>
                          </div>
                          <div className="border">
                            <div className="badge" />
                          </div>
                        </div>
                        <div className="typography193">
                          <div className="security">Security</div>
                        </div>
                        <img
                          className="cancelfilled-icon"
                          alt=""
                          src="/cancelfilled.svg"
                        />
                      </div>
                      <div className="loader163">
                        <div className="loader-rectangles" />
                        <div className="loader-rectangles1" />
                      </div>
                    </div>
                    <div className="chipfilled1">
                      <div className="container13">
                        <div className="avatar2">
                          <div className="avatar3">
                            <div className="op1">OP</div>
                          </div>
                          <div className="border1">
                            <div className="badge1" />
                          </div>
                        </div>
                        <div className="typography194">
                          <div className="back-end">Back-End</div>
                        </div>
                        <img
                          className="cancelfilled-icon1"
                          alt=""
                          src="/cancelfilled.svg"
                        />
                      </div>
                      <div className="chipfilled2">
                        <div className="loader164">
                          <div className="blog-placeholder-image" />
                          <div className="loader-rectangle" />
                        </div>
                        <div className="container14">
                          <div className="avatar4">
                            <div className="avatar5">
                              <div className="op2">OP</div>
                            </div>
                            <div className="border2">
                              <div className="badge2" />
                            </div>
                          </div>
                          <div className="typography195">
                            <div className="security1">Security</div>
                          </div>
                          <img
                            className="cancelfilled-icon2"
                            alt=""
                            src="/cancelfilled.svg"
                          />
                        </div>
                      </div>
                    </div>
                    <div className="chipfilled3">
                      <div className="container15">
                        <div className="avatar6">
                          <div className="avatar7">
                            <div className="op3">OP</div>
                          </div>
                          <div className="border3">
                            <div className="badge3" />
                          </div>
                        </div>
                        <div className="typography196">
                          <div className="chip">Chip</div>
                        </div>
                        <img
                          className="cancelfilled-icon3"
                          alt=""
                          src="/cancelfilled.svg"
                        />
                      </div>
                    </div>
                    <div className="chipfilled4">
                      <div className="container16">
                        <div className="avatar8">
                          <div className="avatar9">
                            <div className="op4">OP</div>
                          </div>
                          <div className="border4">
                            <div className="badge4" />
                          </div>
                        </div>
                        <div className="typography197">
                          <div className="chip1">Chip</div>
                        </div>
                        <img
                          className="cancelfilled-icon4"
                          alt=""
                          src="/cancelfilled.svg"
                        />
                      </div>
                    </div>
                    <div className="chipfilled5">
                      <div className="container17">
                        <div className="avatar10">
                          <div className="avatar11">
                            <div className="op5">OP</div>
                          </div>
                          <div className="border5">
                            <div className="badge5" />
                          </div>
                        </div>
                        <div className="typography198">
                          <div className="chip2">Chip</div>
                        </div>
                        <img
                          className="cancelfilled-icon5"
                          alt=""
                          src="/cancelfilled.svg"
                        />
                      </div>
                    </div>
                  </div>
                </div>
                <div className="loader165">
                  <div className="first-feature-container" />
                  <div className="vertical-spacer" />
                </div>
                <div className="loader166">
                  <div className="rectangle-pair-loader" />
                  <div className="second-feature-container" />
                </div>
              </div>
            </div>
            <div className="loader167">
              <div className="first-loader" />
              <TextField
                className="second-loader"
                variant="outlined"
                sx={{
                  "& fieldset": { border: "none" },
                  "& .MuiInputBase-root": {
                    height: "35.8px",
                    backgroundColor: "#fff",
                    borderRadius: "0px 0px 0px 0px",
                  },
                  width: "149.7px",
                }}
              />
            </div>
          </div>
          <div className="loader168">
            <div className="fourth-loader" />
            <TextField
              className="fifth-loader"
              variant="outlined"
              sx={{
                "& fieldset": { border: "none" },
                "& .MuiInputBase-root": {
                  height: "35.8px",
                  backgroundColor: "#fff",
                  borderRadius: "0px 0px 0px 0px",
                },
                width: "149.7px",
              }}
            />
          </div>
        </div>
        <div className="sixth-loader">
          <div className="loader169">
            <div className="loader-parent" />
            <TextField
              className="rectangle-textfield"
              variant="outlined"
              sx={{
                "& fieldset": { border: "none" },
                "& .MuiInputBase-root": {
                  height: "35.8px",
                  backgroundColor: "#fff",
                  borderRadius: "0px 0px 0px 0px",
                },
                width: "149.7px",
              }}
            />
          </div>
        </div>
      </div>
      <div className="dividerhorizontal52" />
      <div className="cardelementscardactions">
        <div className="buttontext">
          <div className="base">
            <img className="masked-icon" alt="" src="/masked-icon.svg" />
            <div className="button7">ACTION</div>
            <img className="masked-icon1" alt="" src="/masked-icon.svg" />
          </div>
        </div>
        <div className="buttontext1">
          <div className="base1">
            <img className="masked-icon2" alt="" src="/masked-icon.svg" />
            <div className="button8">ACTION</div>
            <img className="masked-icon3" alt="" src="/masked-icon.svg" />
          </div>
        </div>
        <div className="iconbutton8">
          <div className="container18">
            <img className="starfilled-icon1" alt="" src="/starfilled-1.svg" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Card;
