import { TextField, InputAdornment, Icon, IconButton } from "@mui/material";
import NewCaseHalf1 from "./NewCaseHalf1";
import Card2 from "./Card2";
import Card1 from "./Card1";
import "./ReadCaseVariant.css";

const ReadCaseVariant = () => {
  return (
    <section className="read-casevariant2">
      <header className="typography211">
        <div className="header-14">
          <div className="loader198">
            <div className="bookmark-icon8">
              <div className="circle5" />
              <div className="shadow5" />
              <div className="button15">
                <img
                  className="star-icon5"
                  loading="lazy"
                  alt=""
                  src="/star@2x.png"
                />
              </div>
            </div>
            <div className="icon-breadcrumb4">
              <div className="breadcrumb4">
                <h2 className="back-end3">Dashboard</h2>
              </div>
              <h2 className="security6">/</h2>
              <div className="button16">
                <h1 className="loader199">Case 1</h1>
              </div>
            </div>
          </div>
          <div className="spacer-vertical1">
            <div className="search-l5">
              <div className="container-group">
                <div className="typography212">
                  <img
                    className="friday-intel-monogram-black5"
                    loading="lazy"
                    alt=""
                    src="/friday-intel-monogram-black.svg"
                  />
                </div>
                <img
                  className="container-group-child"
                  loading="lazy"
                  alt=""
                  src="/line-249.svg"
                />
                <div className="frame-grid-parent">Type Something|</div>
              </div>
              <img
                className="search-icon6"
                loading="lazy"
                alt=""
                src="/search.svg"
              />
            </div>
            <div className="header-options4">
              <img
                className="timelapse-icon4"
                loading="lazy"
                alt=""
                src="/timelapseicon.svg"
              />
              <img
                className="sun-icon6"
                loading="lazy"
                alt=""
                src="/sunicon@2x.png"
              />
              <img
                className="notify-icon6"
                loading="lazy"
                alt=""
                src="/notifyicon@2x.png"
              />
              <img
                className="user-icon5"
                loading="lazy"
                alt=""
                src="/usericon@2x.png"
              />
            </div>
          </div>
        </div>
      </header>
      <div className="read-casevariant2-inner">
        <div className="frame-parent10">
          <div className="frame-parent11">
            <div className="newcase-half-group">
              <NewCaseHalf1 new1="New" />
              <NewCaseHalf1 new1="Load " />
              <div className="rectangle-parent6">
                <div className="frame-child7" />
                <div className="arrowcircleright5" />
                <img
                  className="loopergroup-icon2"
                  alt=""
                  src="/loopergroup@2x.png"
                />
                <h1 className="read-case1">
                  <span className="read-case-txt-container1">
                    <p className="read1">Read</p>
                    <p className="case9">Case</p>
                  </span>
                </h1>
                <img className="vector-icon3" alt="" src="/vector-1.svg" />
              </div>
            </div>
            <div className="blog-list-wrapper">
              <div className="blog-list1">
                <div className="blog-list2">
                  <div className="card3">
                    <div className="blogpostsplaceholderimage3">
                      <div className="placeholderimage3" />
                      <div className="loader200">
                        <div className="loader-child327" />
                        <div className="frame-icon-button" />
                      </div>
                      <img
                        className="photooutlined-icon3"
                        loading="lazy"
                        alt=""
                        src="/photooutlined.svg"
                      />
                      <div className="iconbutton15">
                        <div className="loader201">
                          <div className="typography213" />
                          <div className="security7" />
                        </div>
                        <div className="container39">
                          <img
                            className="play-icon3"
                            loading="lazy"
                            alt=""
                            src="/play.svg"
                          />
                        </div>
                      </div>
                    </div>
                    <div className="cardelementscardheader3">
                      <div className="content9">
                        <div className="card-header3">Card header</div>
                        <div className="subheader3">Subheader</div>
                      </div>
                      <div className="iconbutton16">
                        <div className="container40">
                          <img
                            className="starfilled-icon6"
                            alt=""
                            src="/starfilled.svg"
                          />
                        </div>
                      </div>
                    </div>
                    <div className="dividerhorizontal57" />
                    <div className="cardelementscardcontent3">
                      <div className="blogpostcardcontent3">
                        <div className="john-doe3">John Doe • 4 Feb 2022</div>
                        <div className="spacervertical9">
                          <div className="frame11">
                            <div className="spacer9" />
                          </div>
                        </div>
                        <div className="chip-filled-play">
                          <h3 className="nea-feature-avaialbe3">
                            Nea feature avaialbe on Zalter
                          </h3>
                          <div className="spacervertical10">
                            <div className="frame12">
                              <div className="spacer10" />
                            </div>
                          </div>
                        </div>
                        <div className="it-is-a3">
                          It is a long established fact that a reader will be
                          distracted by the readable content of a page when
                          looking at its layout.
                        </div>
                        <div className="chip-filled-security3">
                          <div className="spacervertical11">
                            <div className="frame13">
                              <div className="spacer11" />
                            </div>
                          </div>
                          <div className="container41">
                            <div className="chipfilled18">
                              <div className="container42">
                                <div className="avatar36">
                                  <div className="avatar37">
                                    <div className="op18">OP</div>
                                  </div>
                                  <div className="border18">
                                    <div className="badge18" />
                                  </div>
                                </div>
                                <div className="typography214">
                                  <div className="security8">Security</div>
                                </div>
                                <img
                                  className="cancelfilled-icon18"
                                  alt=""
                                  src="/cancelfilled.svg"
                                />
                              </div>
                              <div className="loader202">
                                <div className="container-group1" />
                                <div className="frame-icon-button1" />
                              </div>
                            </div>
                            <div className="chipfilled19">
                              <div className="container43">
                                <div className="avatar38">
                                  <div className="avatar39">
                                    <div className="op19">OP</div>
                                  </div>
                                  <div className="border19">
                                    <div className="badge19" />
                                  </div>
                                </div>
                                <div className="typography215">
                                  <div className="back-end4">Back-End</div>
                                </div>
                                <img
                                  className="cancelfilled-icon19"
                                  alt=""
                                  src="/cancelfilled.svg"
                                />
                              </div>
                              <div className="chipfilled20">
                                <div className="loader203">
                                  <div className="security9" />
                                  <div className="back-end5" />
                                </div>
                                <div className="container44">
                                  <div className="avatar40">
                                    <div className="avatar41">
                                      <div className="op20">OP</div>
                                    </div>
                                    <div className="border20">
                                      <div className="badge20" />
                                    </div>
                                  </div>
                                  <div className="typography216">
                                    <div className="security10">Security</div>
                                  </div>
                                  <img
                                    className="cancelfilled-icon20"
                                    alt=""
                                    src="/cancelfilled.svg"
                                  />
                                </div>
                              </div>
                            </div>
                            <div className="chipfilled21">
                              <div className="container45">
                                <div className="avatar42">
                                  <div className="avatar43">
                                    <div className="op21">OP</div>
                                  </div>
                                  <div className="border21">
                                    <div className="badge21" />
                                  </div>
                                </div>
                                <div className="typography217">
                                  <div className="chip9">Chip</div>
                                </div>
                                <img
                                  className="cancelfilled-icon21"
                                  alt=""
                                  src="/cancelfilled.svg"
                                />
                              </div>
                            </div>
                            <div className="chipfilled22">
                              <div className="container46">
                                <div className="avatar44">
                                  <div className="avatar45">
                                    <div className="op22">OP</div>
                                  </div>
                                  <div className="border22">
                                    <div className="badge22" />
                                  </div>
                                </div>
                                <div className="typography218">
                                  <div className="chip10">Chip</div>
                                </div>
                                <img
                                  className="cancelfilled-icon22"
                                  alt=""
                                  src="/cancelfilled.svg"
                                />
                              </div>
                            </div>
                            <div className="chipfilled23">
                              <div className="container47">
                                <div className="avatar46">
                                  <div className="avatar47">
                                    <div className="op23">OP</div>
                                  </div>
                                  <div className="border23">
                                    <div className="badge23" />
                                  </div>
                                </div>
                                <div className="typography219">
                                  <div className="chip11">Chip</div>
                                </div>
                                <img
                                  className="cancelfilled-icon23"
                                  alt=""
                                  src="/cancelfilled.svg"
                                />
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="loader204">
                          <div className="chip-filled1" />
                          <div className="loader205" />
                        </div>
                        <div className="loader206">
                          <div className="loader207" />
                          <div className="frame-icon-button2" />
                        </div>
                        <div className="loader208">
                          <div className="security-grid" />
                          <div className="frame-icon-button3" />
                        </div>
                        <div className="loader209">
                          <div className="container-chip-filled" />
                          <TextField
                            className="rectangle-rectangle"
                            variant="outlined"
                            sx={{
                              "& fieldset": { border: "none" },
                              "& .MuiInputBase-root": {
                                height: "35.8px",
                                backgroundColor: "#fff",
                                borderRadius: "0px 0px 0px 0px",
                              },
                              width: "149.7px",
                            }}
                          />
                        </div>
                        <div className="loader210">
                          <div className="security-back-end" />
                          <div className="loader-rectangle1" />
                        </div>
                      </div>
                    </div>
                    <div className="dividerhorizontal58" />
                    <div className="cardelementscardactions3">
                      <div className="buttontext6">
                        <div className="base6">
                          <img
                            className="masked-icon12"
                            alt=""
                            src="/masked-icon.svg"
                          />
                          <div className="button17">ACTION</div>
                          <img
                            className="masked-icon13"
                            alt=""
                            src="/masked-icon.svg"
                          />
                        </div>
                      </div>
                      <div className="buttontext7">
                        <div className="base7">
                          <img
                            className="masked-icon14"
                            alt=""
                            src="/masked-icon.svg"
                          />
                          <div className="button18">ACTION</div>
                          <img
                            className="masked-icon15"
                            alt=""
                            src="/masked-icon.svg"
                          />
                        </div>
                      </div>
                      <div className="iconbutton17">
                        <div className="container48">
                          <img
                            className="starfilled-icon7"
                            alt=""
                            src="/starfilled-1.svg"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                  <Card2 />
                  <Card2 />
                </div>
                <div className="blog-list3">
                  <Card1 />
                  <Card1 />
                  <Card1 />
                </div>
                <div className="blog-list4">
                  <div className="card4">
                    <div className="blogpostsplaceholderimage4">
                      <div className="placeholderimage4" />
                      <div className="loader211">
                        <div className="loader-child328" />
                        <div className="loader-child329" />
                      </div>
                      <img
                        className="photooutlined-icon4"
                        alt=""
                        src="/photooutlined.svg"
                      />
                    </div>
                    <div className="cardelementscardheader4">
                      <div className="content10">
                        <div className="card-header4">Card header</div>
                        <div className="subheader4">Subheader</div>
                      </div>
                      <div className="iconbutton18">
                        <div className="container49">
                          <img
                            className="starfilled-icon8"
                            alt=""
                            src="/starfilled.svg"
                          />
                        </div>
                      </div>
                    </div>
                    <div className="dividerhorizontal59" />
                    <div className="cardelementscardcontent4">
                      <div className="blogpostcardcontent4">
                        <div className="john-doe4">John Doe • 4 Feb 2022</div>
                        <div className="spacervertical12">
                          <div className="frame14">
                            <div className="spacer12" />
                          </div>
                        </div>
                        <div className="nea-feature-avaialbe4">
                          Nea feature avaialbe on Zalter
                        </div>
                        <div className="spacervertical13">
                          <div className="frame15">
                            <div className="spacer13" />
                          </div>
                        </div>
                        <div className="it-is-a4">
                          It is a long established fact that a reader will be
                          distracted by the readable content of a page when
                          looking at its layout.
                        </div>
                        <div className="spacervertical14">
                          <div className="frame16">
                            <div className="spacer14" />
                          </div>
                        </div>
                        <div className="container50">
                          <div className="chipfilled24">
                            <div className="container51">
                              <div className="avatar48">
                                <div className="avatar49">
                                  <div className="op24">OP</div>
                                </div>
                                <div className="border24">
                                  <div className="badge24" />
                                </div>
                              </div>
                              <div className="typography220">
                                <div className="security11">Security</div>
                              </div>
                              <img
                                className="cancelfilled-icon24"
                                alt=""
                                src="/cancelfilled.svg"
                              />
                            </div>
                            <div className="loader212">
                              <div className="loader-child330" />
                              <div className="loader-child331" />
                            </div>
                          </div>
                          <div className="chipfilled25">
                            <div className="container52">
                              <div className="avatar50">
                                <div className="avatar51">
                                  <div className="op25">OP</div>
                                </div>
                                <div className="border25">
                                  <div className="badge25" />
                                </div>
                              </div>
                              <div className="typography221">
                                <div className="back-end6">Back-End</div>
                              </div>
                              <img
                                className="cancelfilled-icon25"
                                alt=""
                                src="/cancelfilled.svg"
                              />
                            </div>
                            <div className="chipfilled26">
                              <div className="container53">
                                <div className="avatar52">
                                  <div className="avatar53">
                                    <div className="op26">OP</div>
                                  </div>
                                  <div className="border26">
                                    <div className="badge26" />
                                  </div>
                                </div>
                                <div className="typography222">
                                  <div className="security12">Security</div>
                                </div>
                                <img
                                  className="cancelfilled-icon26"
                                  alt=""
                                  src="/cancelfilled.svg"
                                />
                              </div>
                              <div className="loader213">
                                <div className="loader-child332" />
                                <div className="loader-child333" />
                              </div>
                            </div>
                          </div>
                          <div className="chipfilled27">
                            <div className="container54">
                              <div className="avatar54">
                                <div className="avatar55">
                                  <div className="op27">OP</div>
                                </div>
                                <div className="border27">
                                  <div className="badge27" />
                                </div>
                              </div>
                              <div className="typography223">
                                <div className="chip12">Chip</div>
                              </div>
                              <img
                                className="cancelfilled-icon27"
                                alt=""
                                src="/cancelfilled.svg"
                              />
                            </div>
                          </div>
                          <div className="chipfilled28">
                            <div className="container55">
                              <div className="avatar56">
                                <div className="avatar57">
                                  <div className="op28">OP</div>
                                </div>
                                <div className="border28">
                                  <div className="badge28" />
                                </div>
                              </div>
                              <div className="typography224">
                                <div className="chip13">Chip</div>
                              </div>
                              <img
                                className="cancelfilled-icon28"
                                alt=""
                                src="/cancelfilled.svg"
                              />
                            </div>
                          </div>
                          <div className="chipfilled29">
                            <div className="container56">
                              <div className="avatar58">
                                <div className="avatar59">
                                  <div className="op29">OP</div>
                                </div>
                                <div className="border29">
                                  <div className="badge29" />
                                </div>
                              </div>
                              <div className="typography225">
                                <div className="chip14">Chip</div>
                              </div>
                              <img
                                className="cancelfilled-icon29"
                                alt=""
                                src="/cancelfilled.svg"
                              />
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="loader214">
                        <div className="loader-child334" />
                        <div className="loader-child335" />
                      </div>
                      <div className="loader215">
                        <div className="loader-child336" />
                        <div className="loader-child337" />
                      </div>
                      <div className="loader216">
                        <div className="loader-child338" />
                        <div className="loader-child339" />
                      </div>
                      <div className="loader217">
                        <div className="loader-child340" />
                        <div className="loader-child341" />
                      </div>
                      <div className="loader218">
                        <div className="loader-child342" />
                        <div className="loader-child343" />
                      </div>
                    </div>
                    <div className="dividerhorizontal60" />
                    <div className="cardelementscardactions4">
                      <div className="buttontext8">
                        <div className="base8">
                          <img
                            className="masked-icon16"
                            alt=""
                            src="/masked-icon.svg"
                          />
                          <div className="button19">ACTION</div>
                          <img
                            className="masked-icon17"
                            alt=""
                            src="/masked-icon.svg"
                          />
                        </div>
                      </div>
                      <div className="buttontext9">
                        <div className="base9">
                          <img
                            className="masked-icon18"
                            alt=""
                            src="/masked-icon.svg"
                          />
                          <div className="button20">ACTION</div>
                          <img
                            className="masked-icon19"
                            alt=""
                            src="/masked-icon.svg"
                          />
                        </div>
                      </div>
                      <div className="iconbutton19">
                        <div className="container57">
                          <img
                            className="starfilled-icon9"
                            alt=""
                            src="/starfilled-1.svg"
                          />
                        </div>
                      </div>
                    </div>
                    <div className="iconbutton20">
                      <div className="container58">
                        <img className="play-icon4" alt="" src="/play.svg" />
                      </div>
                      <div className="loader219">
                        <div className="loader-child344" />
                        <div className="loader-child345" />
                      </div>
                    </div>
                  </div>
                  <div className="card5">
                    <div className="blogpostsplaceholderimage5">
                      <div className="placeholderimage5" />
                      <div className="loader220">
                        <div className="loader-child346" />
                        <div className="loader-child347" />
                      </div>
                      <img
                        className="photooutlined-icon5"
                        alt=""
                        src="/photooutlined.svg"
                      />
                    </div>
                    <div className="cardelementscardheader5">
                      <div className="content11">
                        <div className="card-header5">Card header</div>
                        <div className="subheader5">Subheader</div>
                      </div>
                      <div className="iconbutton21">
                        <div className="container59">
                          <img
                            className="starfilled-icon10"
                            alt=""
                            src="/starfilled.svg"
                          />
                        </div>
                      </div>
                    </div>
                    <div className="dividerhorizontal61" />
                    <div className="cardelementscardcontent5">
                      <div className="blogpostcardcontent5">
                        <div className="john-doe5">John Doe • 4 Feb 2022</div>
                        <div className="spacervertical15">
                          <div className="frame17">
                            <div className="spacer15" />
                          </div>
                        </div>
                        <div className="nea-feature-avaialbe5">
                          Nea feature avaialbe on Zalter
                        </div>
                        <div className="spacervertical16">
                          <div className="frame18">
                            <div className="spacer16" />
                          </div>
                        </div>
                        <div className="it-is-a5">
                          It is a long established fact that a reader will be
                          distracted by the readable content of a page when
                          looking at its layout.
                        </div>
                        <div className="spacervertical17">
                          <div className="frame19">
                            <div className="spacer17" />
                          </div>
                        </div>
                        <div className="container60">
                          <div className="chipfilled30">
                            <div className="container61">
                              <div className="avatar60">
                                <div className="avatar61">
                                  <div className="op30">OP</div>
                                </div>
                                <div className="border30">
                                  <div className="badge30" />
                                </div>
                              </div>
                              <div className="typography226">
                                <div className="security13">Security</div>
                              </div>
                              <img
                                className="cancelfilled-icon30"
                                alt=""
                                src="/cancelfilled.svg"
                              />
                            </div>
                            <div className="loader221">
                              <div className="loader-child348" />
                              <div className="loader-child349" />
                            </div>
                          </div>
                          <div className="chipfilled31">
                            <div className="container62">
                              <div className="avatar62">
                                <div className="avatar63">
                                  <div className="op31">OP</div>
                                </div>
                                <div className="border31">
                                  <div className="badge31" />
                                </div>
                              </div>
                              <div className="typography227">
                                <div className="back-end7">Back-End</div>
                              </div>
                              <img
                                className="cancelfilled-icon31"
                                alt=""
                                src="/cancelfilled.svg"
                              />
                            </div>
                            <div className="chipfilled32">
                              <div className="container63">
                                <div className="avatar64">
                                  <div className="avatar65">
                                    <div className="op32">OP</div>
                                  </div>
                                  <div className="border32">
                                    <div className="badge32" />
                                  </div>
                                </div>
                                <div className="typography228">
                                  <div className="security14">Security</div>
                                </div>
                                <img
                                  className="cancelfilled-icon32"
                                  alt=""
                                  src="/cancelfilled.svg"
                                />
                              </div>
                              <div className="loader222">
                                <div className="loader-child350" />
                                <div className="loader-child351" />
                              </div>
                            </div>
                          </div>
                          <div className="chipfilled33">
                            <div className="container64">
                              <div className="avatar66">
                                <div className="avatar67">
                                  <div className="op33">OP</div>
                                </div>
                                <div className="border33">
                                  <div className="badge33" />
                                </div>
                              </div>
                              <div className="typography229">
                                <div className="chip15">Chip</div>
                              </div>
                              <img
                                className="cancelfilled-icon33"
                                alt=""
                                src="/cancelfilled.svg"
                              />
                            </div>
                          </div>
                          <div className="chipfilled34">
                            <div className="container65">
                              <div className="avatar68">
                                <div className="avatar69">
                                  <div className="op34">OP</div>
                                </div>
                                <div className="border34">
                                  <div className="badge34" />
                                </div>
                              </div>
                              <div className="typography230">
                                <div className="chip16">Chip</div>
                              </div>
                              <img
                                className="cancelfilled-icon34"
                                alt=""
                                src="/cancelfilled.svg"
                              />
                            </div>
                          </div>
                          <div className="chipfilled35">
                            <div className="container66">
                              <div className="avatar70">
                                <div className="avatar71">
                                  <div className="op35">OP</div>
                                </div>
                                <div className="border35">
                                  <div className="badge35" />
                                </div>
                              </div>
                              <div className="typography231">
                                <div className="chip17">Chip</div>
                              </div>
                              <img
                                className="cancelfilled-icon35"
                                alt=""
                                src="/cancelfilled.svg"
                              />
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="loader223">
                        <div className="loader-child352" />
                        <div className="loader-child353" />
                      </div>
                      <div className="loader224">
                        <div className="loader-child354" />
                        <div className="loader-child355" />
                      </div>
                      <div className="loader225">
                        <div className="loader-child356" />
                        <div className="loader-child357" />
                      </div>
                      <div className="loader226">
                        <div className="loader-child358" />
                        <div className="loader-child359" />
                      </div>
                      <div className="loader227">
                        <div className="loader-child360" />
                        <div className="loader-child361" />
                      </div>
                    </div>
                    <div className="dividerhorizontal62" />
                    <div className="cardelementscardactions5">
                      <div className="buttontext10">
                        <div className="base10">
                          <img
                            className="masked-icon20"
                            alt=""
                            src="/masked-icon.svg"
                          />
                          <div className="button21">ACTION</div>
                          <img
                            className="masked-icon21"
                            alt=""
                            src="/masked-icon.svg"
                          />
                        </div>
                      </div>
                      <div className="buttontext11">
                        <div className="base11">
                          <img
                            className="masked-icon22"
                            alt=""
                            src="/masked-icon.svg"
                          />
                          <div className="button22">ACTION</div>
                          <img
                            className="masked-icon23"
                            alt=""
                            src="/masked-icon.svg"
                          />
                        </div>
                      </div>
                      <div className="iconbutton22">
                        <div className="container67">
                          <img
                            className="starfilled-icon11"
                            alt=""
                            src="/starfilled-1.svg"
                          />
                        </div>
                      </div>
                    </div>
                    <div className="iconbutton23">
                      <div className="container68">
                        <img className="play-icon5" alt="" src="/play.svg" />
                      </div>
                      <div className="loader228">
                        <div className="loader-child362" />
                        <div className="loader-child363" />
                      </div>
                    </div>
                  </div>
                  <div className="card6">
                    <div className="blogpostsplaceholderimage6">
                      <div className="placeholderimage6" />
                      <div className="loader229">
                        <div className="loader-child364" />
                        <div className="loader-child365" />
                      </div>
                      <img
                        className="photooutlined-icon6"
                        alt=""
                        src="/photooutlined.svg"
                      />
                    </div>
                    <div className="cardelementscardheader6">
                      <div className="content12">
                        <div className="card-header6">Card header</div>
                        <div className="subheader6">Subheader</div>
                      </div>
                      <div className="iconbutton24">
                        <div className="container69">
                          <img
                            className="starfilled-icon12"
                            alt=""
                            src="/starfilled.svg"
                          />
                        </div>
                      </div>
                    </div>
                    <div className="dividerhorizontal63" />
                    <div className="cardelementscardcontent6">
                      <div className="blogpostcardcontent6">
                        <div className="john-doe6">John Doe • 4 Feb 2022</div>
                        <div className="spacervertical18">
                          <div className="frame20">
                            <div className="spacer18" />
                          </div>
                        </div>
                        <div className="nea-feature-avaialbe6">
                          Nea feature avaialbe on Zalter
                        </div>
                        <div className="spacervertical19">
                          <div className="frame21">
                            <div className="spacer19" />
                          </div>
                        </div>
                        <div className="it-is-a6">
                          It is a long established fact that a reader will be
                          distracted by the readable content of a page when
                          looking at its layout.
                        </div>
                        <div className="spacervertical20">
                          <div className="frame22">
                            <div className="spacer20" />
                          </div>
                        </div>
                        <div className="container70">
                          <div className="chipfilled36">
                            <div className="container71">
                              <div className="avatar72">
                                <div className="avatar73">
                                  <div className="op36">OP</div>
                                </div>
                                <div className="border36">
                                  <div className="badge36" />
                                </div>
                              </div>
                              <div className="typography232">
                                <div className="security15">Security</div>
                              </div>
                              <img
                                className="cancelfilled-icon36"
                                alt=""
                                src="/cancelfilled.svg"
                              />
                            </div>
                            <div className="loader230">
                              <div className="loader-child366" />
                              <div className="loader-child367" />
                            </div>
                          </div>
                          <div className="chipfilled37">
                            <div className="container72">
                              <div className="avatar74">
                                <div className="avatar75">
                                  <div className="op37">OP</div>
                                </div>
                                <div className="border37">
                                  <div className="badge37" />
                                </div>
                              </div>
                              <div className="typography233">
                                <div className="back-end8">Back-End</div>
                              </div>
                              <img
                                className="cancelfilled-icon37"
                                alt=""
                                src="/cancelfilled.svg"
                              />
                            </div>
                            <div className="chipfilled38">
                              <div className="container73">
                                <div className="avatar76">
                                  <div className="avatar77">
                                    <div className="op38">OP</div>
                                  </div>
                                  <div className="border38">
                                    <div className="badge38" />
                                  </div>
                                </div>
                                <div className="typography234">
                                  <div className="security16">Security</div>
                                </div>
                                <img
                                  className="cancelfilled-icon38"
                                  alt=""
                                  src="/cancelfilled.svg"
                                />
                              </div>
                              <div className="loader231">
                                <div className="loader-child368" />
                                <div className="loader-child369" />
                              </div>
                            </div>
                          </div>
                          <div className="chipfilled39">
                            <div className="container74">
                              <div className="avatar78">
                                <div className="avatar79">
                                  <div className="op39">OP</div>
                                </div>
                                <div className="border39">
                                  <div className="badge39" />
                                </div>
                              </div>
                              <div className="typography235">
                                <div className="chip18">Chip</div>
                              </div>
                              <img
                                className="cancelfilled-icon39"
                                alt=""
                                src="/cancelfilled.svg"
                              />
                            </div>
                          </div>
                          <div className="chipfilled40">
                            <div className="container75">
                              <div className="avatar80">
                                <div className="avatar81">
                                  <div className="op40">OP</div>
                                </div>
                                <div className="border40">
                                  <div className="badge40" />
                                </div>
                              </div>
                              <div className="typography236">
                                <div className="chip19">Chip</div>
                              </div>
                              <img
                                className="cancelfilled-icon40"
                                alt=""
                                src="/cancelfilled.svg"
                              />
                            </div>
                          </div>
                          <div className="chipfilled41">
                            <div className="container76">
                              <div className="avatar82">
                                <div className="avatar83">
                                  <div className="op41">OP</div>
                                </div>
                                <div className="border41">
                                  <div className="badge41" />
                                </div>
                              </div>
                              <div className="typography237">
                                <div className="chip20">Chip</div>
                              </div>
                              <img
                                className="cancelfilled-icon41"
                                alt=""
                                src="/cancelfilled.svg"
                              />
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="loader232">
                        <div className="loader-child370" />
                        <div className="loader-child371" />
                      </div>
                      <div className="loader233">
                        <div className="loader-child372" />
                        <div className="loader-child373" />
                      </div>
                      <div className="loader234">
                        <div className="loader-child374" />
                        <div className="loader-child375" />
                      </div>
                      <div className="loader235">
                        <div className="loader-child376" />
                        <div className="loader-child377" />
                      </div>
                      <div className="loader236">
                        <div className="loader-child378" />
                        <div className="loader-child379" />
                      </div>
                    </div>
                    <div className="dividerhorizontal64" />
                    <div className="cardelementscardactions6">
                      <div className="buttontext12">
                        <div className="base12">
                          <img
                            className="masked-icon24"
                            alt=""
                            src="/masked-icon.svg"
                          />
                          <div className="button23">ACTION</div>
                          <img
                            className="masked-icon25"
                            alt=""
                            src="/masked-icon.svg"
                          />
                        </div>
                      </div>
                      <div className="buttontext13">
                        <div className="base13">
                          <img
                            className="masked-icon26"
                            alt=""
                            src="/masked-icon.svg"
                          />
                          <div className="button24">ACTION</div>
                          <img
                            className="masked-icon27"
                            alt=""
                            src="/masked-icon.svg"
                          />
                        </div>
                      </div>
                      <div className="iconbutton25">
                        <div className="container77">
                          <img
                            className="starfilled-icon13"
                            alt=""
                            src="/starfilled-1.svg"
                          />
                        </div>
                      </div>
                    </div>
                    <div className="iconbutton26">
                      <div className="container78">
                        <img className="play-icon6" alt="" src="/play.svg" />
                      </div>
                      <div className="loader237">
                        <div className="loader-child380" />
                        <div className="loader-child381" />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="frame-stack" />
        </div>
      </div>
    </section>
  );
};

export default ReadCaseVariant;
