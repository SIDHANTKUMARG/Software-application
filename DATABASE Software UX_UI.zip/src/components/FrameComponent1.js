import "./FrameComponent1.css";

const FrameComponent1 = ({ notifyIcon }) => {
  return (
    <section className="header-1-container">
      <header className="header-13">
        <div className="bookmark-icon-group">
          <div className="bookmark-icon7">
            <div className="circle4" />
            <div className="shadow4" />
            <div className="button9">
              <img className="star-icon4" alt="" src="/star@2x.png" />
            </div>
          </div>
          <div className="icon-breadcrumb3">
            <div className="breadcrumb3">
              <h3 className="text1">Dashboard</h3>
            </div>
            <h3 className="h3">/</h3>
            <div className="button10">
              <h2 className="text2">Case 1</h2>
            </div>
          </div>
        </div>
        <div className="search-l-parent">
          <div className="search-l4">
            <div className="frame-parent9">
              <div className="friday-intel-monogram-black-wrapper">
                <img
                  className="friday-intel-monogram-black4"
                  loading="lazy"
                  alt=""
                  src="/friday-intel-monogram-black.svg"
                />
              </div>
              <img className="line-icon" alt="" src="/line-249.svg" />
              <div className="text3">Type Something|</div>
            </div>
            <img
              className="search-icon5"
              loading="lazy"
              alt=""
              src="/search.svg"
            />
          </div>
          <div className="header-options3">
            <img
              className="timelapse-icon3"
              loading="lazy"
              alt=""
              src="/timelapseicon.svg"
            />
            <img
              className="sun-icon5"
              loading="lazy"
              alt=""
              src="/sunicon@2x.png"
            />
            <img
              className="notify-icon5"
              loading="lazy"
              alt=""
              src={notifyIcon}
            />
            <img
              className="user-icon4"
              loading="lazy"
              alt=""
              src="/usericon@2x.png"
            />
          </div>
        </div>
      </header>
    </section>
  );
};

export default FrameComponent1;
