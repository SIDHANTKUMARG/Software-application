import "./MainFRAME1.css";

const MainFRAME1 = () => {
  return (
    <header className="main-f-r-a-m-e">
      <div className="header1">
        <img
          className="friday-intel-wordmark-black3"
          loading="lazy"
          alt=""
          src="/friday-intel-wordmark-black.svg"
        />
        <div className="content-f-r-a-m-e">
          <div className="bookmark-frame">
            <div className="search-frame1">
              <img
                className="bookmark-icon9"
                loading="lazy"
                alt=""
                src="/bookmarkicon2@2x.png"
              />
              <div className="search-l6">
                <div className="load-caption">
                  <div className="buttons-group">
                    <img
                      className="friday-intel-monogram-black6"
                      loading="lazy"
                      alt=""
                      src="/friday-intel-monogram-black.svg"
                    />
                  </div>
                  <img
                    className="load-caption-child"
                    loading="lazy"
                    alt=""
                    src="/line-249.svg"
                  />
                  <div className="search-t-e">Type Something|</div>
                </div>
                <img
                  className="search-icon7"
                  loading="lazy"
                  alt=""
                  src="/search.svg"
                />
              </div>
            </div>
            <div className="alert-f-r-a-m-e">
              <img
                className="timelapse-icon5"
                loading="lazy"
                alt=""
                src="/timelapseicon.svg"
              />
              <img
                className="sun-icon7"
                loading="lazy"
                alt=""
                src="/sunicon@2x.png"
              />
              <img
                className="notify-icon8"
                loading="lazy"
                alt=""
                src="/notifyicon1@2x.png"
              />
              <img
                className="timelapse-icon-exp"
                loading="lazy"
                alt=""
                src="/timelapseiconexp.svg"
              />
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default MainFRAME1;
