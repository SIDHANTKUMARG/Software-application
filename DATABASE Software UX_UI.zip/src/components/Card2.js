import { TextField, InputAdornment, Icon, IconButton } from "@mui/material";
import "./Card2.css";

const Card2 = () => {
  return (
    <div className="card1">
      <div className="blogpostsplaceholderimage1">
        <div className="placeholderimage1" />
        <div className="loader177">
          <div className="loader-rectangle-loader" />
          <div className="chip-filled-security" />
        </div>
        <img className="photooutlined-icon1" alt="" src="/photooutlined.svg" />
        <div className="iconbutton9">
          <div className="loader178">
            <div className="typography-back-end" />
            <div className="security-front-end" />
          </div>
          <div className="container19">
            <img className="play-icon1" alt="" src="/play.svg" />
          </div>
        </div>
      </div>
      <div className="cardelementscardheader1">
        <div className="content7">
          <div className="card-header1">Card header</div>
          <div className="subheader1">Subheader</div>
        </div>
        <div className="iconbutton10">
          <div className="container20">
            <img className="starfilled-icon2" alt="" src="/starfilled.svg" />
          </div>
        </div>
      </div>
      <div className="dividerhorizontal53" />
      <div className="cardelementscardcontent1">
        <div className="blogpostcardcontent1">
          <div className="john-doe1">John Doe • 4 Feb 2022</div>
          <div className="spacervertical3">
            <div className="frame5">
              <div className="spacer3" />
            </div>
          </div>
          <div className="nea-feature-avaialbe-on-zalter-parent">
            <h3 className="nea-feature-avaialbe1">
              Nea feature avaialbe on Zalter
            </h3>
            <div className="spacervertical4">
              <div className="frame6">
                <div className="spacer4" />
              </div>
            </div>
          </div>
          <div className="it-is-a1">
            It is a long established fact that a reader will be distracted by
            the readable content of a page when looking at its layout.
          </div>
          <div className="security-chips-loader">
            <div className="spacervertical5">
              <div className="frame7">
                <div className="spacer5" />
              </div>
            </div>
            <div className="container21">
              <div className="chipfilled6">
                <div className="container22">
                  <div className="avatar12">
                    <div className="avatar13">
                      <div className="op6">OP</div>
                    </div>
                    <div className="border6">
                      <div className="badge6" />
                    </div>
                  </div>
                  <div className="typography199">
                    <div className="security2">Security</div>
                  </div>
                  <img
                    className="cancelfilled-icon6"
                    alt=""
                    src="/cancelfilled.svg"
                  />
                </div>
                <div className="loader179">
                  <div className="loader-child315" />
                  <div className="loader180" />
                </div>
              </div>
              <div className="chipfilled7">
                <div className="container23">
                  <div className="avatar14">
                    <div className="avatar15">
                      <div className="op7">OP</div>
                    </div>
                    <div className="border7">
                      <div className="badge7" />
                    </div>
                  </div>
                  <div className="typography200">
                    <div className="back-end1">Back-End</div>
                  </div>
                  <img
                    className="cancelfilled-icon7"
                    alt=""
                    src="/cancelfilled.svg"
                  />
                </div>
                <div className="chipfilled8">
                  <div className="loader181">
                    <div className="loader182" />
                    <div className="loader183" />
                  </div>
                  <div className="container24">
                    <div className="avatar16">
                      <div className="avatar17">
                        <div className="op8">OP</div>
                      </div>
                      <div className="border8">
                        <div className="badge8" />
                      </div>
                    </div>
                    <div className="typography201">
                      <div className="security3">Security</div>
                    </div>
                    <img
                      className="cancelfilled-icon8"
                      alt=""
                      src="/cancelfilled.svg"
                    />
                  </div>
                </div>
              </div>
              <div className="chipfilled9">
                <div className="container25">
                  <div className="avatar18">
                    <div className="avatar19">
                      <div className="op9">OP</div>
                    </div>
                    <div className="border9">
                      <div className="badge9" />
                    </div>
                  </div>
                  <div className="typography202">
                    <div className="chip3">Chip</div>
                  </div>
                  <img
                    className="cancelfilled-icon9"
                    alt=""
                    src="/cancelfilled.svg"
                  />
                </div>
              </div>
              <div className="chipfilled10">
                <div className="container26">
                  <div className="avatar20">
                    <div className="avatar21">
                      <div className="op10">OP</div>
                    </div>
                    <div className="border10">
                      <div className="badge10" />
                    </div>
                  </div>
                  <div className="typography203">
                    <div className="chip4">Chip</div>
                  </div>
                  <img
                    className="cancelfilled-icon10"
                    alt=""
                    src="/cancelfilled.svg"
                  />
                </div>
              </div>
              <div className="chipfilled11">
                <div className="container27">
                  <div className="avatar22">
                    <div className="avatar23">
                      <div className="op11">OP</div>
                    </div>
                    <div className="border11">
                      <div className="badge11" />
                    </div>
                  </div>
                  <div className="typography204">
                    <div className="chip5">Chip</div>
                  </div>
                  <img
                    className="cancelfilled-icon11"
                    alt=""
                    src="/cancelfilled.svg"
                  />
                </div>
              </div>
            </div>
          </div>
          <div className="loader184">
            <div className="chip-filled-a" />
            <div className="chip-filled-b" />
          </div>
          <div className="loader185">
            <div className="loader-child316" />
            <TextField
              className="frame-icon-button-a"
              variant="outlined"
              sx={{
                "& fieldset": { border: "none" },
                "& .MuiInputBase-root": {
                  height: "35.8px",
                  backgroundColor: "#fff",
                  borderRadius: "0px 0px 0px 0px",
                },
                width: "149.7px",
              }}
            />
          </div>
          <div className="loader186">
            <div className="loader-child317" />
            <TextField
              className="rectangle-parent-a"
              variant="outlined"
              sx={{
                "& fieldset": { border: "none" },
                "& .MuiInputBase-root": {
                  height: "35.8px",
                  backgroundColor: "#fff",
                  borderRadius: "0px 0px 0px 0px",
                },
                width: "149.7px",
              }}
            />
          </div>
          <div className="loader187">
            <div className="chip-filled-d" />
            <TextField
              className="loader-child318"
              variant="outlined"
              sx={{
                "& fieldset": { border: "none" },
                "& .MuiInputBase-root": {
                  height: "35.8px",
                  backgroundColor: "#fff",
                  borderRadius: "0px 0px 0px 0px",
                },
                width: "149.7px",
              }}
            />
          </div>
          <div className="loader188">
            <div className="frame-icon-button-b" />
            <div className="loader-child319" />
          </div>
        </div>
      </div>
      <div className="dividerhorizontal54" />
      <div className="cardelementscardactions1">
        <div className="buttontext2">
          <div className="base2">
            <img className="masked-icon4" alt="" src="/masked-icon.svg" />
            <div className="button11">ACTION</div>
            <img className="masked-icon5" alt="" src="/masked-icon.svg" />
          </div>
        </div>
        <div className="buttontext3">
          <div className="base3">
            <img className="masked-icon6" alt="" src="/masked-icon.svg" />
            <div className="button12">ACTION</div>
            <img className="masked-icon7" alt="" src="/masked-icon.svg" />
          </div>
        </div>
        <div className="iconbutton11">
          <div className="container28">
            <img className="starfilled-icon3" alt="" src="/starfilled-1.svg" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Card2;
