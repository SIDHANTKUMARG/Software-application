import { useState } from "react";
import "./FrameComponent.css";

const FrameComponent = () => {
  const [arrowLineRight2IconChecked, setArrowLineRight2IconChecked] =
    useState(true);
  return (
    <div className="sidebar-on-load-parent">
      <div className="sidebar-on-load">
        <div className="arrow-wrapper">
          <div className="arrow">
            <div className="arrow-child" />
            <img
              className="arrowlinedown2-icon"
              loading="lazy"
              alt=""
              src="/arrowlinedown2@2x.png"
            />
          </div>
        </div>
        <div className="sidebar-on-load-inner">
          <div className="nav-parent">
            <div className="nav">
              <div className="finnthehuman-parent">
                <img
                  className="finnthehuman-icon3"
                  alt=""
                  src="/finnthehuman.svg"
                />
                <div className="terrorist-profiling-parent">
                  <div className="terrorist-profiling">Terrorist Profiling</div>
                  <div className="loader170">
                    <div className="loader-child301" />
                    <div className="loader-child302" />
                  </div>
                </div>
              </div>
              <div className="pages-wrapper">
                <div className="pages">
                  <div className="sidebar-item-container">
                    <div className="sidebar-item">
                      <div className="sidebar-item-child" />
                      <input
                        className="arrowlineright2"
                        checked={arrowLineRight2IconChecked}
                        type="checkbox"
                        onChange={(event) =>
                          setArrowLineRight2IconChecked(event.target.checked)
                        }
                      />
                      <img
                        className="arrowlinedown-s-icon"
                        alt=""
                        src="/arrowlinedowns.svg"
                      />
                      <img
                        className="globe-icon"
                        loading="lazy"
                        alt=""
                        src="/globe@2x.png"
                      />
                      <div className="messenger-logo">Network Info</div>
                      <div className="loader171">
                        <div className="loader-child303" />
                        <div className="loader-child304" />
                      </div>
                    </div>
                    <div className="sidebar-item1">
                      <div className="sidebar-item-item" />
                      <input className="arrowlineright21" type="checkbox" />
                      <div className="text4">File Info</div>
                      <img
                        className="file-icon"
                        loading="lazy"
                        alt=""
                        src="/file@2x.png"
                      />
                      <div className="loader172">
                        <div className="loader-child305" />
                        <div className="loader-child306" />
                      </div>
                    </div>
                    <div className="sidebar-item2">
                      <div className="sidebar-item-inner" />
                      <input className="arrowlineright22" type="checkbox" />
                      <img
                        className="filelock-icon"
                        alt=""
                        src="/filelock@2x.png"
                      />
                      <div className="text5">Leaked Info</div>
                      <div className="loader173">
                        <div className="loader-child307" />
                        <div className="loader-child308" />
                      </div>
                    </div>
                    <div className="sidebar-item3">
                      <div className="sidebar-item-child1" />
                      <input className="arrowlineright23" type="checkbox" />
                      <div className="text6">SNS Info</div>
                      <img
                        className="messengerlogo-icon"
                        alt=""
                        src="/messengerlogo.svg"
                      />
                      <div className="loader174">
                        <div className="loader-child309" />
                        <div className="loader-child310" />
                      </div>
                    </div>
                    <div className="sidebar-item4">
                      <div className="sidebar-item-child2" />
                      <input className="arrowlineright24" type="checkbox" />
                      <div className="text7">Custom Info</div>
                      <img className="octagon-icon" alt="" src="/octagon.svg" />
                      <div className="loader175">
                        <div className="loader-child311" />
                        <div className="loader-child312" />
                      </div>
                    </div>
                    <div className="sidebar-item5">
                      <div className="sidebar-item-child3" />
                      <input className="arrowlineright25" type="checkbox" />
                      <img
                        className="usersthree-icon"
                        alt=""
                        src="/usersthree@2x.png"
                      />
                      <div className="text8">External Search Info</div>
                      <div className="loader176">
                        <div className="loader-child313" />
                        <div className="loader-child314" />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="arrows-cardinal">
              <div className="try-frame" />
            </div>
          </div>
        </div>
      </div>
      <img
        className="arrowsoutcardinal-icon1"
        loading="lazy"
        alt=""
        src="/arrowsoutcardinal@2x.png"
      />
    </div>
  );
};

export default FrameComponent;
