import "./MainFrame.css";

const MainFrame = ({ rectangleReadCase, onSearchLContainerClick }) => {
  return (
    <header className="main-frame">
      <div className="header-p">
        <img
          className="friday-intel-wordmark-black2"
          loading="lazy"
          alt=""
          src="/friday-intel-wordmark-black.svg"
        />
        <div className="inner-frame1">
          <div className="bookmark-icon5">
            <img
              className="bookmark-icon6"
              loading="lazy"
              alt=""
              src="/bookmarkicon@2x.png"
            />
            <div className="line-separator">
              <div className="search-l3" onClick={onSearchLContainerClick}>
                <div className="sun-icon3">
                  <div className="notify-icon3">
                    <img
                      className="friday-intel-monogram-black3"
                      loading="lazy"
                      alt=""
                      src="/friday-intel-monogram-black.svg"
                    />
                  </div>
                  <img
                    className="sun-icon-child"
                    loading="lazy"
                    alt=""
                    src="/line-249.svg"
                  />
                  <div className="rectangle-read-case">{rectangleReadCase}</div>
                </div>
                <img
                  className="search-icon4"
                  loading="lazy"
                  alt=""
                  src="/search.svg"
                />
              </div>
            </div>
            <div className="read-frame">
              <img
                className="sun-icon4"
                loading="lazy"
                alt=""
                src="/sunicon@2x.png"
              />
              <img
                className="notify-icon4"
                loading="lazy"
                alt=""
                src="/notifyicon@2x.png"
              />
              <img
                className="user-icon3"
                loading="lazy"
                alt=""
                src="/usericon@2x.png"
              />
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default MainFrame;
