import "./Card1.css";

const Card1 = () => {
  return (
    <div className="card2">
      <div className="blogpostsplaceholderimage2">
        <div className="placeholderimage2" />
        <div className="loader189">
          <div className="loader-child320" />
          <div className="loader-child321" />
        </div>
        <img className="photooutlined-icon2" alt="" src="/photooutlined.svg" />
      </div>
      <div className="cardelementscardheader2">
        <div className="content8">
          <div className="card-header2">Card header</div>
          <div className="subheader2">Subheader</div>
        </div>
        <div className="iconbutton12">
          <div className="container29">
            <img className="starfilled-icon4" alt="" src="/starfilled.svg" />
          </div>
        </div>
      </div>
      <div className="dividerhorizontal55" />
      <div className="dividerhorizontal56" />
      <div className="cardelementscardactions2">
        <div className="buttontext4">
          <div className="base4">
            <img className="masked-icon8" alt="" src="/masked-icon.svg" />
            <div className="button13">ACTION</div>
            <img className="masked-icon9" alt="" src="/masked-icon.svg" />
          </div>
        </div>
        <div className="buttontext5">
          <div className="base5">
            <img className="masked-icon10" alt="" src="/masked-icon.svg" />
            <div className="button14">ACTION</div>
            <img className="masked-icon11" alt="" src="/masked-icon.svg" />
          </div>
        </div>
        <div className="iconbutton13">
          <div className="container30">
            <img className="starfilled-icon5" alt="" src="/starfilled-1.svg" />
          </div>
        </div>
      </div>
      <div className="cardelementscardcontent-wrapper">
        <div className="cardelementscardcontent2">
          <div className="blogpostcardcontent2">
            <div className="john-doe2">John Doe • 4 Feb 2022</div>
            <div className="spacervertical6">
              <div className="frame8">
                <div className="spacer6" />
              </div>
            </div>
            <div className="nea-feature-avaialbe-on-zalter-group">
              <h3 className="nea-feature-avaialbe2">
                Nea feature avaialbe on Zalter
              </h3>
              <div className="spacervertical7">
                <div className="frame9">
                  <div className="spacer7" />
                </div>
              </div>
            </div>
            <div className="it-is-a2">
              It is a long established fact that a reader will be distracted by
              the readable content of a page when looking at its layout.
            </div>
            <div className="spacervertical-parent">
              <div className="spacervertical8">
                <div className="frame10">
                  <div className="spacer8" />
                </div>
              </div>
              <div className="container31">
                <div className="chipfilled12">
                  <div className="container32">
                    <div className="avatar24">
                      <div className="avatar25">
                        <div className="op12">OP</div>
                      </div>
                      <div className="border12">
                        <div className="badge12" />
                      </div>
                    </div>
                    <div className="typography205">
                      <div className="security4">Security</div>
                    </div>
                    <img
                      className="cancelfilled-icon12"
                      alt=""
                      src="/cancelfilled.svg"
                    />
                  </div>
                  <div className="loader190">
                    <div className="loader-child322" />
                    <div className="chip-filled-security1" />
                  </div>
                </div>
                <div className="chipfilled13">
                  <div className="container33">
                    <div className="avatar26">
                      <div className="avatar27">
                        <div className="op13">OP</div>
                      </div>
                      <div className="border13">
                        <div className="badge13" />
                      </div>
                    </div>
                    <div className="typography206">
                      <div className="back-end2">Back-End</div>
                    </div>
                    <img
                      className="cancelfilled-icon13"
                      alt=""
                      src="/cancelfilled.svg"
                    />
                  </div>
                  <div className="chipfilled14">
                    <div className="loader191">
                      <div className="loader-child323" />
                      <div className="loader-child324" />
                    </div>
                    <div className="container34">
                      <div className="avatar28">
                        <div className="avatar29">
                          <div className="op14">OP</div>
                        </div>
                        <div className="border14">
                          <div className="badge14" />
                        </div>
                      </div>
                      <div className="typography207">
                        <div className="security5">Security</div>
                      </div>
                      <img
                        className="cancelfilled-icon14"
                        alt=""
                        src="/cancelfilled.svg"
                      />
                    </div>
                  </div>
                </div>
                <div className="chipfilled15">
                  <div className="container35">
                    <div className="avatar30">
                      <div className="avatar31">
                        <div className="op15">OP</div>
                      </div>
                      <div className="border15">
                        <div className="badge15" />
                      </div>
                    </div>
                    <div className="typography208">
                      <div className="chip6">Chip</div>
                    </div>
                    <img
                      className="cancelfilled-icon15"
                      alt=""
                      src="/cancelfilled.svg"
                    />
                  </div>
                </div>
                <div className="chipfilled16">
                  <div className="container36">
                    <div className="avatar32">
                      <div className="avatar33">
                        <div className="op16">OP</div>
                      </div>
                      <div className="border16">
                        <div className="badge16" />
                      </div>
                    </div>
                    <div className="typography209">
                      <div className="chip7">Chip</div>
                    </div>
                    <img
                      className="cancelfilled-icon16"
                      alt=""
                      src="/cancelfilled.svg"
                    />
                  </div>
                </div>
                <div className="chipfilled17">
                  <div className="container37">
                    <div className="avatar34">
                      <div className="avatar35">
                        <div className="op17">OP</div>
                      </div>
                      <div className="border17">
                        <div className="badge17" />
                      </div>
                    </div>
                    <div className="typography210">
                      <div className="chip8">Chip</div>
                    </div>
                    <img
                      className="cancelfilled-icon17"
                      alt=""
                      src="/cancelfilled.svg"
                    />
                  </div>
                </div>
              </div>
            </div>
            <div className="loader192">
              <div className="loader-child325" />
              <div className="loader-child326" />
            </div>
            <div className="loader193">
              <div className="frame-icon-button-loader" />
              <div className="container-chip-filled-typograp" />
            </div>
            <div className="loader194">
              <div className="chip-filled-back-end" />
              <div className="loader-rectangle-rectangle" />
            </div>
            <div className="loader195">
              <div className="chip-filled-security2" />
              <div className="loader-rectangle-rectangle1" />
            </div>
            <div className="loader196">
              <div className="loader-rectangle-rectangle2" />
              <div className="frame-icon-button-loader-play" />
            </div>
          </div>
          <div className="iconbutton14">
            <div className="loader197">
              <div className="container-chip-filled-typograp1" />
              <div className="loader-rectangle-rectangle3" />
            </div>
            <div className="container38">
              <img className="play-icon2" alt="" src="/play.svg" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Card1;
