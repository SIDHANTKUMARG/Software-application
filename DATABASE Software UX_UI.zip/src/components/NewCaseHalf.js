import { useMemo } from "react";
import "./NewCaseHalf.css";

const NewCaseHalf = ({
  new1,
  propMarginLeft,
  propWidth,
  propAlignSelf,
  propTop,
  propBottom,
}) => {
  const newCaseHalfStyle = useMemo(() => {
    return {
      marginLeft: propMarginLeft,
      width: propWidth,
      alignSelf: propAlignSelf,
    };
  }, [propMarginLeft, propWidth, propAlignSelf]);

  const blogPostCardContentStyle = useMemo(() => {
    return {
      top: propTop,
      bottom: propBottom,
    };
  }, [propTop, propBottom]);

  return (
    <div className="newcase-half1" style={newCaseHalfStyle}>
      <div className="table-header" />
      <div className="arrowcircleright3" />
      <div className="checkbox-cell">
        <h1 className="new-case3">
          <span className="new-case-txt-container">
            <p className="new">{new1}</p>
            <p className="case7">Case</p>
          </span>
        </h1>
        <img
          className="blog-post-card-content"
          loading="lazy"
          alt=""
          src="/vector.svg"
          style={blogPostCardContentStyle}
        />
      </div>
    </div>
  );
};

export default NewCaseHalf;
