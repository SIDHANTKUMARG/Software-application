import { useMemo } from "react";
import "./Input.css";

const Input = ({ propAlignSelf, propWidth, propWidth1 }) => {
  const inputStyle = useMemo(() => {
    return {
      alignSelf: propAlignSelf,
      width: propWidth,
    };
  }, [propAlignSelf, propWidth]);

  const namecompanycomStyle = useMemo(() => {
    return {
      width: propWidth1,
    };
  }, [propWidth1]);

  return (
    <div className="input" style={inputStyle}>
      <div className="email-address">Email address</div>
      <div className="input1">
        <input
          className="namecompanycom"
          placeholder="name@company.com"
          type="text"
          style={namecompanycomStyle}
        />
      </div>
    </div>
  );
};

export default Input;
